# HOME — Android Visual Workspace Launcher

**Current source package:** 0.16.0  
**Platform:** Android  
**Implementation:** Kotlin + Jetpack Compose

HOME is evolving from a conventional launcher prototype into a visual workspace creator. The product direction combines customizable compositions, spatial placement, HOME-owned widgets, native Android widgets, and portable Homepacks.

## Current prototype

- Android HOME/default launcher and regular LAUNCHER entry points.
- Installed-app discovery, search, launch, app context menu, and shortcut placement.
- GRID and FREE positioning, 1–5 workspace pages, and horizontal Wide mode.
- Native Android widgets through `AppWidgetHost` / `AppWidgetManager`.
- HOME clock widget and custom declarative widgets.
- Visual component tree with nested containers, component ordering, hide/show, lock/unlock, and basic editing tools.
- Workspace-level HIDE/SHOW and LOCK/UNLOCK controls for app shortcuts, HOME Widgets, and native Android Widgets.
- Homepack v3 export/import for HOME Widgets, shortcut placements, canvas metadata, and supported image assets.
- Room schema and typed workspace tables used as a mirror/recovery representation.

## Important implementation boundaries

- SharedPreferences is still the active UI persistence authority. Room is not yet the canonical source of truth.
- Spatial workspace model classes exist, but the launcher does not yet use one unified canvas-object model for every object family.
- Workspace-level visibility and placement locking are implemented for app shortcuts and both widget families; workspace-wide z-order, groups, and transforms remain future work.
- Wide mode is a bounded horizontal workspace, not an infinite canvas. Vertical navigation and pinch zoom are not implemented.
- Native Android widget IDs are device-local and are not exported in Homepacks.
- AI Studio, Applets runtime, workspace-wide groups/layers, cloud sync, and optional editor bridges are future work.

## Build environment

- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9 (CI workflow)
- Kotlin 2.0.21

Open the project in Android Studio or run `gradle :app:assembleDebug` in a configured environment.

## Project documentation

- `HOME_Product_Specification.md` — product vision, features, boundaries, and current status.
- `HOME_Engineering_Architecture.md` — current implementation, target architecture, data models, persistence, Homepack, and safety.
- `HOME_Implementation_Roadmap.md` — release scope, status, acceptance criteria, and future phases.
- `SPATIAL_WORKSPACE_SPEC_0.13.md` — historical implementation note for the initial spatial-workspace foundation.
- `CHANGELOG_0.16.0.md` — workspace-level layer controls and page restoration correction; previous release notes are retained separately.

## Verification status

HOME 0.15.1 was confirmed by the user as built and tested on-device. The 0.16.0 package has passed archive and source-level structural checks in the preparation environment; a Gradle/APK build and physical-device testing have not been performed for 0.16.0. Do not treat static checks as proof of runtime correctness.
