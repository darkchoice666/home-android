# HOME 0.13.5

- On first launch HOME now asks Android to become the default Home app (system role dialog, RoleManager ROLE_HOME). It asks once per install; declining does not repeat the prompt.
- The workspace menu item "Default home app" asks again whenever HOME is not the default, and opens the system Home settings when it already is or when the dialog is unavailable.

## Known limits
- Some device shells (for example MIUI/HyperOS) may show their own screen or restrict the dialog.
- Back button behavior on the workspace is unchanged.

## Verification limits
Source-level changes only. Gradle/APK build and on-device behavior have not been run.
