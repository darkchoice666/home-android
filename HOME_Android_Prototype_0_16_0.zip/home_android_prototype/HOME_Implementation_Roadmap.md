# HOME — Implementation Roadmap

**Baseline:** HOME 0.16.0 (built from user-confirmed, device-tested 0.15.1)  
**Status convention:** Implemented = present in source; Partial = foundation or limited path exists; Planned = not implemented. Device verification is tracked separately.

## 1. Current baseline audit

| Area | Status | Evidence / current limit |
|---|---|---|
| Android launcher and app discovery | Implemented | `MainActivity`, manifest HOME and LAUNCHER filters |
| Default launcher request | Implemented | Activity requests Android default HOME role/settings |
| App shortcuts and context menu | Implemented | App placement, app info, uninstall, app shortcuts |
| GRID / FREE positioning | Implemented, basic | UI-level placement and snapping; not a standalone workspace engine |
| 1–5 page workspace | Implemented in UI | `page_count`, page navigation, add page |
| Wide horizontal mode | Partial | Horizontal composition across current page records; no general viewport engine |
| Free Canvas | Partial | Current free-position mode only; no infinite canvas, pinch zoom, or vertical navigation |
| Native Android Widgets | Implemented, prototype scope | AppWidgetHost, picker/configuration flow, local placement IDs |
| HOME clock widget | Implemented | Live time/date, 12/24h, styling |
| HOME custom widget builder | Implemented, limited | Declarative component tree and visual properties |
| Component and workspace object visibility/locking | Implemented, bounded | HOME Widget component controls plus workspace-level HIDE/SHOW and LOCK/UNLOCK for app shortcuts, HOME Widgets, and native Android Widgets; no unified z-order/groups yet |
| Undo/redo and multi-select | Implemented in Studio source | Bounded editor history and selection controls |
| Homepack v3 | Implemented, bounded | Widgets, shortcut placements, canvas metadata, embedded images; no native widget IDs |
| Room persistence | Partial | Typed normalized tables and mirror/recovery; SharedPreferences remains authoritative |
| Spatial canonical model | Partial | Data classes and layout resolver exist but are not integrated as the sole workspace model |
| Workspace-wide groups and z-order | Planned | Visibility and placement locking exist across object families; shared ordering, groups, and transforms are not implemented |
| Applets runtime | Planned | No applet execution/runtime or logic graph |
| AI Studio / HOME AI Blueprint | Planned | Product design defined; no implementation |
| Kustom / external editor bridges | Planned | Optional integration only; no core dependency |
| Cloud sync | Planned | Offline-first local app remains the priority |
| Product-focused home visual design | Partial | Current UI remains a technical prototype and needs a composed visual workspace redesign |

## 2. HOME 0.15.1 — page consistency and layer foundation

**Scope:** incremental release; no global data-model or persistence-authority migration.

- Carry forward HOME Widget component hide/show and lock/unlock from 0.14.0.
- Preserve hidden/locked flags through JSON serialization and Homepack round trips; older files default to visible/unlocked.
- Load HOME Widgets on pages 0–4, matching the current five-page workspace.
- Mirror the actual configured page count into Room rather than always writing three page rows.
- Keep SharedPreferences as the active UI store and Room as a mirror.
- Raise versionCode to 24 and versionName to 0.15.1.

**Acceptance criteria:**
- A widget placed on page 4 remains on page 4 after process restart.
- A Room snapshot contains the same 1–5 page count as the configured workspace and referenced objects.
- Hiding a component removes it from preview/rendering but retains it in the component tree.
- Locked components remain selectable in the layer tree but cannot be dragged or resized on the canvas.
- Existing Homepack files without `hidden`/`locked` fields import as visible and unlocked.
- Existing launcher gestures, menus, app placement, native widget flows, and default launcher behavior remain intact.

**Verification status:** source and archive checks are to be run for this package; APK build and device testing are not claimed unless performed separately.

## 2A. HOME 0.16.0 — workspace object visibility and placement locking

**Scope:** extend the existing layer concept to the three current workspace object families without replacing the legacy storage or Homepack schema.

- Add an Edit-mode LAYERS menu for app shortcuts, HOME Widgets, and native Android Widgets.
- Persist HIDE/SHOW and LOCK/UNLOCK state using optional `workspace_layers` metadata.
- Hidden objects remain recoverable through the layer menu; locked objects cannot be moved, and widgets cannot be resized.
- Include portable app/HOME Widget layer state in Homepack canvas metadata; keep native widget state device-local.
- Remap HOME Widget layer keys when imported widget IDs collide.
- Correct HOME Widget page restoration to accept page indices 0–4.
- Keep SharedPreferences authoritative and Room as mirror/recovery representation.

**Acceptance criteria:**
- Each of the three object families can be hidden and restored from the LAYERS menu.
- Locked objects cannot be moved; locked widgets cannot be resized.
- State survives process restart.
- App and HOME Widget state round-trips through Homepack; native widget state does not transfer.
- Older Homepacks without layer metadata import with default visible/unlocked state.
- A HOME Widget assigned to page 4 remains on page 4 after restart.

**Verification status:** source/archive checks only in the preparation environment; no Gradle build or physical-device test claimed.

## 3. Next implementation phases

### Phase A — persistence and workspace repository

1. Define repository contracts around existing data without changing the document format.
2. Add parity checks between SharedPreferences and Room snapshots.
3. Persist dynamic page metadata and canvas settings consistently.
4. Add recovery tests for empty preferences and existing Room data.
5. Migrate one data family at a time only after parity is proven.

**Exit criteria:** repository snapshots match the active workspace; migration is idempotent and recoverable; UI behavior remains unchanged.

### Phase B — unified spatial workspace model

1. Define a stable `CanvasObject` contract that can represent app icons, folders, HOME Widgets, native widgets, and decoration objects.
2. Map existing legacy records into the model without destructive conversion.
3. Move coordinate conversion, snapping, hit testing, and viewport math out of UI gesture code.
4. Add z-order, visibility, lock, and grouping metadata at workspace scope.
5. Integrate the renderer against immutable workspace snapshots.

**Exit criteria:** existing content renders identically through the new model; GRID and FREE coexist; migration round-trip preserves positions and page identity.

### Phase C — product-facing workspace and editor

1. Redesign the normal home screen as a visual composition surface, not a technical control panel.
2. Keep import/export and management actions in menus/editor rather than on the ordinary workspace.
3. Introduce a polished Easy Editor flow.
4. Expand Pro Editor with workspace-wide layers, group/ungroup, lock/hide, ordering, opacity, and multi-object transforms.
5. Add undo/redo at the workspace transaction level.

**Exit criteria:** the ordinary home screen is visually useful without entering edit mode; Easy and Pro edit the same document; all operations persist and undo safely.

### Phase D — object catalogue and responsive canvas

1. Add stickers, photo frames, standalone images, text, shapes, containers, and folders as first-class canvas objects.
2. Add responsive layout variants for phones and tablets.
3. Improve viewport navigation and optional zoom.
4. Add collision and safe-area policies without preventing intentional overlap.

**Exit criteria:** object types share the same placement, selection, layer, persistence, and Homepack contracts.

### Phase E — HOME Widgets and Applets

1. Stabilize the component registry with type IDs, property schemas, child policies, events, and accessibility metadata.
2. Add typed data providers and lifecycle contracts.
3. Define bounded interaction graphs for Applets.
4. Validate cycles, capabilities, and execution budgets; never execute arbitrary imported code.

**Exit criteria:** applets are deterministic, bounded, serializable, and safe to import.

### Phase F — Homepack 4 and AI Studio

1. Add explicit schema migration framework and duplicate-entry rejection.
2. Export/import all portable canvas objects, groups, layers, variants, applet definitions, and assets.
3. Keep Android widget IDs device-local and restore native widgets as rebind placeholders or setup prompts.
4. Publish HOME AI Blueprint.
5. Accept structured JSON from API, Sharesheet, pasted text, or files; validate and preview before import.

**Exit criteria:** old Homepacks remain readable; new packs round-trip; AI output cannot execute code or bypass validation.

### Phase G — optional integrations

- Kustom bridge through supported interfaces only.
- External Editor API/Bridge.
- Optional cloud backup/sync after local persistence is stable.

These must remain optional and must not compromise offline-first operation.

## 4. Release discipline

- Start from the latest user-confirmed working archive.
- Make only changes needed for the agreed release scope; local subsystem refactors are allowed when they improve conceptual correctness.
- Global schema, persistence-authority, toolchain, or architecture changes require explicit approval and a migration plan.
- Do not change `.github`, dependencies, or tool versions without permission.
- Do not remove working gestures or launcher behavior.
- Increment versionCode/versionName and create a separate changelog.
- Run archive, manifest, source, and compatibility checks before delivery.
- State separately whether Gradle build and physical-device tests were performed.
