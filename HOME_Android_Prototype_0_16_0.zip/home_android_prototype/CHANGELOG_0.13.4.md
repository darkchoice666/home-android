# HOME 0.13.4

- The top bar with EDIT and WIDE/PAGED is removed. On a normal workspace there is no header.
- Long-press on an empty spot of a workspace opens a menu at that spot: Edit, Wide view / Paged view, Wallpaper, Android widget, HOME widget, Export HOME pack, Import HOME pack, Default home app (system setting).
- Edit mode shows a small header with GRID/FREE and DONE.
- Wallpaper opens the system wallpaper chooser. HOME now shows the system wallpaper behind the workspace (theme windowShowWallpaper, background dimmed by about 50% for readability).
- Long-press menu is disabled in edit mode, where drags move elements.

## Known limits
- Long-press on an app icon opens that app's own menu; on a widget it may be handled by the widget.
- Wallpaper visibility depends on the device and Android version.

## Verification limits
Source-level changes only. Gradle/APK build and on-device behavior (menu position, wallpaper display) have not been run.
