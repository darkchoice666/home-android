# HOME — Product Specification

**Document status:** living product specification  
**Current implementation baseline:** HOME 0.15.0 source package  
**Product type:** Android launcher and visual workspace creator

## 1. Product vision

HOME is a customizable visual environment for the Android home screen. It combines the visual composition and sharing ideas associated with Buzz Launcher with the spatial workspace, free placement, and interactive mini-elements associated with Wide Launcher, while using its own data model and implementation.

HOME is not intended to remain a conventional icon grid with a theme picker. The workspace should become a user-composed surface containing applications, widgets, visual objects, and small interactive applets.

## 2. Product principles

- **User-created space first.** The ordinary home screen is a visual workspace, not an administration dashboard.
- **Easy and Pro editing.** Both modes operate on one underlying document model; Easy hides complexity, Pro exposes it.
- **Hybrid placement.** GRID placement supports predictable alignment; FREE placement supports composition without forcing every object into cells.
- **Offline-first.** Core launcher and editing functions must work without an account or network connection.
- **Portable design.** Homepack exports portable workspace content and resources, not device-bound Android widget IDs or unavailable applications.
- **Safe extensibility.** Imported packs and AI-generated content are declarative data. They must never execute arbitrary code.
- **Backward compatibility.** Existing workspace data and supported Homepack formats should continue to load through explicit defaults and migrations.
- **Incremental evolution.** Improve individual subsystems where possible. Global data-model, persistence-authority, or format changes require an explicit migration plan and approval.

## 3. Workspace modes

The product direction includes three presentation modes over a shared workspace document:

1. **Standard / Paged** — one screen-sized page at a time.
2. **Wide** — a horizontally navigable workspace spanning multiple screen widths.
3. **Free Canvas** — a more open spatial surface with free positioning and, eventually, zoom and two-dimensional navigation.

The workspace width is not conceptually fixed to three pages. The current prototype supports 1–5 horizontal pages. The present UI does not yet implement an infinite canvas, vertical panning, or pinch zoom.

## 4. Canvas object families

Target object types:

- App Icon and Folder
- HOME Widget
- Native Android Widget
- Applet
- Sticker and Image
- Photo Frame
- Text and Shape
- Container / Group

**Current implementation status:** app icons, HOME Widgets, and native Android Widgets are represented in the active launcher flow. HOME Widget component trees currently support text, image, shape, spacer, container, row, column, and box. The broader canvas object catalogue is a product target, not a claim that every type already exists.

## 5. Widgets and editing

### Native Android Widgets

Use Android's `AppWidgetHost` / `AppWidgetManager` lifecycle and provider configuration. IDs are local to the device. Native widgets must be rebound or configured again after importing a Homepack on another device.

### HOME Widgets

HOME-owned widgets use a declarative component tree and HOME's own renderer. Current examples include a clock and custom visual widgets. Component data is allowlisted and bounded.

### Easy / Pro editor direction

- Easy: guided insertion, common sizing, positioning, and styling controls.
- Pro: component tree, layer ordering, visibility, locking, multi-selection, undo/redo, and detailed properties.
- Both edit the same underlying document representation.

HOME Widget components have their own nested hide/show and lock/unlock controls. Since 0.16.0, workspace-level hide/show and placement locking also apply to app shortcuts, HOME Widgets, and native Android Widgets. Shared z-order, grouping, and transforms across all workspace objects remain future work.

## 6. Homepack and sharing

Homepack is a ZIP-based portable format. The current implementation writes format version 3 and workspace schema version 3, containing HOME Widgets, app shortcut placements, canvas metadata, and optional content-addressed image assets.

- Existing format/schema versions 1–3 are accepted.
- Image assets are validated by SHA-256 and supported image format checks.
- App shortcuts are restored only when their package is installed.
- Native Android widget IDs and provider state are intentionally not exported.
- Import merges widgets and shortcuts with existing content; duplicate widget IDs are regenerated.

Future Homepack evolution should add explicit migrations and validation for new object families, layers, groups, responsive variants, and applet definitions without allowing executable payloads.

## 7. AI Studio — planned optional subsystem

AI Studio is an optional authoring assistant, not a dependency of the launcher core. It may work with ChatGPT, Gemini, other providers, API-based generation, or external-app handoff through Android Sharesheet.

HOME should provide a versioned HOME AI Blueprint describing supported objects, properties, constraints, and a structured output format. It should accept structured JSON embedded in ordinary text, validate it, create a preview, and import it as a Homepack. The model must not supply executable code for the launcher to run.

AI Studio is not implemented in the current prototype.

## 8. External integrations

- Kustom integration may be added as an optional bridge using supported interfaces. HOME must remain fully functional without Kustom.
- External editors may integrate through a small, optional editor bridge. They must not become a core dependency.
- Cloud sync and accounts are future optional capabilities; local operation remains primary.

## 9. Non-goals and safety boundaries

- No arbitrary Kotlin, JavaScript, shell, or other executable code from Homepacks or AI output.
- No requirement for a network connection to launch apps or edit local content.
- No transfer of device-local `appWidgetId` values as if they were portable identifiers.
- No assumption that a declared model class or document field means its feature is already connected to the UI or persistence layer.

## 10. Current release snapshot (0.15.0)

Implemented in source:
- Android launcher entry points for HOME/default selection and normal launcher listing.
- App discovery, search, launch, shortcut placement, GRID/FREE editing, and 1–5 page workspace UI.
- Wide horizontal presentation mode.
- Native Android widget host and placement persistence.
- HOME clock and custom declarative widgets.
- Component tree editing, nested containers, basic layer order, visibility and lock flags, multi-selection, undo/redo, and Homepack v3.
- Room database and typed tables as a mirror/recovery representation.

Known implementation gaps:
- SharedPreferences remains the active UI persistence authority; Room is not canonical.
- Spatial model classes and layout resolver are foundations, not yet the active unified renderer/model for every workspace object.
- Room page records are now mirrored dynamically for 1–5 pages, but the launcher UI still reads/writes the legacy preferences and JSON records.
- Workspace-wide layer/group system, Applets runtime, AI Studio, responsive layout variants, infinite canvas, pinch zoom, vertical navigation, and cloud sync are not implemented.
- The ordinary home screen's visual design still needs a product-focused redesign toward a composed workspace rather than a technical prototype interface.

## 11. Release acceptance principle

A release is not considered device-verified until the user or a real device test confirms installation, launcher selection, basic navigation, editing, persistence after process restart, and Homepack round-trip. Static source checks and archive integrity must be reported separately from APK build and device testing.
