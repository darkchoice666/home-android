# HOME 0.13.7

- Added support for expanding the workspace from the default three pages up to five pages.
- Added a `+ PAGE` control in edit mode. A new page becomes the active page immediately.
- Wide Workspace now sizes its horizontal canvas from the configured page count.
- The page indicator and horizontal swipe navigation follow the current page count.
- Homepack canvas metadata exports the configured page count; imports restore it when present.
- Homepack validation and native-widget/Room mirror page bounds now accept pages 1–5.
- Existing workspaces and Homepacks without page-count metadata retain the three-page default.

## Verification limits

Source-level checks only. Gradle build, APK generation, and on-device behavior have not been run in this environment.
