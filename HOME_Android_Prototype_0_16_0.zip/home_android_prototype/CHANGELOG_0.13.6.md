# HOME 0.13.6

- Drag an app from the app drawer to the home screen: hold an icon in the drawer and move it. The drawer hides, a floating icon follows the finger, and releasing it over the workspace places the app on the current page (snapped to the grid in GRID mode). Releasing outside the workspace cancels and leaves the drawer open.
- Holding an icon without moving still opens its menu (App info, Uninstall, app shortcuts).
- Tap behavior in the drawer is unchanged (launch, or add to the page in edit mode). Hint text updated.
- If the app is already on the current page it is moved to the new spot instead of duplicated.

## Known limits
- Dropping always targets the page that is currently shown; moving to another page while dragging is not supported yet.
- No highlighted drop target or edge-scroll while dragging.

## Verification limits
Source-level changes only. Gradle/APK build and on-device drag behavior have not been run.
