package com.home.launcher

import android.content.Context
import android.net.Uri
import android.widget.ImageView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import com.home.launcher.data.RoomWorkspaceStore
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Portable declarative node. No executable code is allowed in a Homepack. */
data class HomeComponent(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val text: String = "",
    val colorArgb: Long = 0xFFFFFFFFL,
    val size: Float = 18f,
    val padding: Int = 4,
    val imageUri: String = "",
    val children: List<HomeComponent> = emptyList(),
    val layout: String = "column", // row | column | box
    val x: Float = 0.05f,
    val y: Float = 0.05f,
    val width: Float = 0.9f,
    val height: Float = 0.2f,
    val alpha: Float = 1f,
    val alignment: String = "start",
    val hidden: Boolean = false,
    val locked: Boolean = false
)

data class HomeWidgetDefinition(
    val id: String = UUID.randomUUID().toString(), val name: String = "Clock", val type: String = "clock",
    val backgroundArgb: Long = 0xFF253247, val foregroundArgb: Long = 0xFFFFFFFF,
    val use24Hour: Boolean = true, val showDate: Boolean = true, val fontScale: Float = 1f,
    val x: Float = 0.04f, val y: Float = 0.12f, val widthDp: Int = 220, val heightDp: Int = 112,
    val page: Int = 0, val components: List<HomeComponent> = emptyList()
)

private const val MAX_COMPONENTS = 80
private val allowedComponentTypes = setOf("text", "shape", "spacer", "container", "image", "row", "column", "box")

private fun componentToJson(c: HomeComponent, depth: Int = 0): JSONObject {
    require(depth <= 6)
    return JSONObject().put("id", c.id).put("type", c.type).put("text", c.text.take(500))
        .put("color", c.colorArgb).put("size", c.size.coerceIn(4f, 240f).toDouble())
        .put("padding", c.padding.coerceIn(0, 48)).put("imageUri", c.imageUri.take(2048))
        .put("layout", c.layout).put("x", c.x.coerceIn(0f, 1f).toDouble()).put("y", c.y.coerceIn(0f, 1f).toDouble())
        .put("width", c.width.coerceIn(0.05f, 1f).toDouble()).put("height", c.height.coerceIn(0.05f, 1f).toDouble())
        .put("alpha", c.alpha.coerceIn(0f, 1f).toDouble()).put("alignment", c.alignment)
        .put("hidden", c.hidden).put("locked", c.locked)
        .put("children", JSONArray().apply { c.children.take(MAX_COMPONENTS).forEach { put(componentToJson(it, depth + 1)) } })
}

fun componentsToJson(components: List<HomeComponent>): JSONArray = JSONArray().apply {
    components.take(MAX_COMPONENTS).forEach { put(componentToJson(it)) }
}

private fun componentFromJson(o: JSONObject, depth: Int, counter: IntArray): HomeComponent? = runCatching {
    require(depth <= 6 && ++counter[0] <= MAX_COMPONENTS)
    val type = o.optString("type")
    require(type in allowedComponentTypes)
    val childrenJson = o.optJSONArray("children") ?: JSONArray()
    val children = (0 until minOf(childrenJson.length(), MAX_COMPONENTS)).mapNotNull { componentFromJson(childrenJson.getJSONObject(it), depth + 1, counter) }
    HomeComponent(
        id = o.optString("id").ifBlank { UUID.randomUUID().toString() }, type = type,
        text = o.optString("text").take(500), colorArgb = o.optLong("color", 0xFFFFFFFFL),
        size = o.optDouble("size", 18.0).toFloat().coerceIn(4f, 240f), padding = o.optInt("padding", 4).coerceIn(0, 48),
        imageUri = o.optString("imageUri").take(2048), children = children,
        layout = o.optString("layout", "column").takeIf { it in setOf("row", "column", "box") } ?: "column",
        x = o.optDouble("x", 0.05).toFloat().coerceIn(0f, 1f), y = o.optDouble("y", 0.05).toFloat().coerceIn(0f, 1f),
        width = o.optDouble("width", 0.9).toFloat().coerceIn(0.05f, 1f), height = o.optDouble("height", 0.2).toFloat().coerceIn(0.05f, 1f),
        alpha = o.optDouble("alpha", 1.0).toFloat().coerceIn(0f, 1f),
        alignment = o.optString("alignment", "start").takeIf { it in setOf("start", "center", "end") } ?: "start",
        hidden = o.optBoolean("hidden", false), locked = o.optBoolean("locked", false)
    )
}.getOrNull()

fun componentsFromJson(array: JSONArray?): List<HomeComponent> {
    if (array == null) return emptyList()
    val counter = intArrayOf(0)
    return (0 until minOf(array.length(), MAX_COMPONENTS)).mapNotNull { componentFromJson(array.getJSONObject(it), 0, counter) }
}

private fun widgetToJson(w: HomeWidgetDefinition) = JSONObject().put("id", w.id).put("name", w.name).put("type", w.type)
    .put("bg", w.backgroundArgb).put("fg", w.foregroundArgb).put("24h", w.use24Hour).put("date", w.showDate)
    .put("scale", w.fontScale.toDouble()).put("x", w.x.toDouble()).put("y", w.y.toDouble())
    .put("w", w.widthDp).put("h", w.heightDp).put("page", w.page).put("components", componentsToJson(w.components))

fun loadHomeWidgets(context: Context): List<HomeWidgetDefinition> {
    val raw = context.getSharedPreferences("home_workspace", Context.MODE_PRIVATE).getString("home_widgets", null) ?: return emptyList()
    return runCatching {
        val a = JSONArray(raw)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            HomeWidgetDefinition(
                id = o.optString("id", UUID.randomUUID().toString()), name = o.optString("name", "Clock"), type = o.optString("type", "clock"),
                backgroundArgb = o.optLong("bg", 0xFF253247), foregroundArgb = o.optLong("fg", -1L),
                use24Hour = o.optBoolean("24h", true), showDate = o.optBoolean("date", true),
                fontScale = o.optDouble("scale", 1.0).toFloat().coerceIn(0.7f, 1.5f),
                x = o.optDouble("x", 0.04).toFloat().coerceIn(0f, 0.9f), y = o.optDouble("y", 0.12).toFloat().coerceIn(0f, 0.9f),
                widthDp = o.optInt("w", 220).coerceIn(140, 420), heightDp = o.optInt("h", 112).coerceIn(80, 260),
                page = o.optInt("page", 0).coerceIn(0, 4), components = componentsFromJson(o.optJSONArray("components"))
            )
        }
    }.getOrDefault(emptyList())
}

fun saveHomeWidgets(context: Context, widgets: List<HomeWidgetDefinition>) {
    val a = JSONArray()
    widgets.forEach { a.put(widgetToJson(it)) }
    context.getSharedPreferences("home_workspace", Context.MODE_PRIVATE).edit().putString("home_widgets", a.toString()).apply()
    RoomWorkspaceStore.scheduleMirror(context)
}

@Composable
fun HomeWidgetRenderer(definition: HomeWidgetDefinition, modifier: Modifier = Modifier, editing: Boolean = false) {
    if (definition.type == "custom" || definition.components.isNotEmpty()) HomeCustomWidget(definition, modifier)
    else HomeClockWidget(definition, modifier, editing)
}

@Composable
fun HomeClockWidget(definition: HomeWidgetDefinition, modifier: Modifier = Modifier, editing: Boolean = false) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(definition.id) { while (true) { kotlinx.coroutines.delay(1000); now = System.currentTimeMillis() } }
    val timePattern = if (definition.use24Hour) "HH:mm" else "h:mm a"
    val time = remember(now, definition.use24Hour) { SimpleDateFormat(timePattern, Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(now)) }
    Column(modifier.background(Color(definition.backgroundArgb.toInt()), RoundedCornerShape(18.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.Start) {
        Text(time, color = Color(definition.foregroundArgb.toInt()), fontSize = (36 * definition.fontScale).sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        if (definition.showDate) Text(date, color = Color(definition.foregroundArgb.toInt()).copy(alpha = 0.78f), fontSize = (13 * definition.fontScale).sp)
        if (editing) Text("HOME CLOCK", color = Color(definition.foregroundArgb.toInt()).copy(alpha = 0.55f), fontSize = 8.sp)
    }
}

@Composable
private fun HomeCustomWidget(
    definition: HomeWidgetDefinition,
    modifier: Modifier = Modifier,
    editing: Boolean = false,
    selectedId: String? = null,
    snapToGrid: Boolean = true,
    onSelect: (String) -> Unit = {},
    onMove: (String, Float, Float) -> Unit = { _, _, _ -> },
    onResize: (String, Float, Float) -> Unit = { _, _, _ -> }
) {
    BoxWithConstraints(modifier.background(Color(definition.backgroundArgb.toInt()), RoundedCornerShape(16.dp)).padding(8.dp)) {
        val w = maxWidth
        val h = maxHeight
        // Subtle alignment grid is visible only while editing.
        if (editing && snapToGrid) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val stepX = size.width / 20f
                val stepY = size.height / 10f
                for (i in 1 until 20) drawLine(Color.White.copy(alpha = .055f), androidx.compose.ui.geometry.Offset(i * stepX, 0f), androidx.compose.ui.geometry.Offset(i * stepX, size.height), 1f)
                for (i in 1 until 10) drawLine(Color.White.copy(alpha = .055f), androidx.compose.ui.geometry.Offset(0f, i * stepY), androidx.compose.ui.geometry.Offset(size.width, i * stepY), 1f)
                // Center guides help visually align elements even when snapping is enabled.
                drawLine(Color(0x668AB4F8), androidx.compose.ui.geometry.Offset(size.width / 2f, 0f), androidx.compose.ui.geometry.Offset(size.width / 2f, size.height), 1.2f)
                drawLine(Color(0x668AB4F8), androidx.compose.ui.geometry.Offset(0f, size.height / 2f), androidx.compose.ui.geometry.Offset(size.width, size.height / 2f), 1.2f)
            }
        }
        definition.components.forEachIndexed { layerIndex, node ->
            if (!node.hidden) key(node.id) {
                val isSelected = editing && node.id == selectedId
                Box(Modifier.offset(x = w * node.x, y = h * node.y).width(w * node.width).height(h * node.height)
                    .zIndex(if (isSelected) 10000f else layerIndex.toFloat())
                    .then(if (isSelected) Modifier.border(1.5.dp, Color(0xFF8AB4F8), RoundedCornerShape(5.dp)) else Modifier)
                    .pointerInput(editing, node.id, w, h, snapToGrid) {
                        if (editing && !node.locked) detectDragGestures(onDragStart = { onSelect(node.id) }) { change, drag ->
                            change.consume()
                            val dx = drag.x / w.toPx().coerceAtLeast(1f)
                            val dy = drag.y / h.toPx().coerceAtLeast(1f)
                            onMove(node.id, if (snapToGrid) (dx * 20f).roundToInt() / 20f else dx,
                                if (snapToGrid) (dy * 10f).roundToInt() / 10f else dy)
                        }
                    }
                    .clickable(enabled = editing) { onSelect(node.id) }) {
                    HomeComponentRenderer(node, Modifier.fillMaxSize())
                    if (isSelected && !node.locked) {
                        Box(Modifier.align(Alignment.BottomEnd).size(20.dp).clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF8AB4F8)).pointerInput(node.id, w, h, snapToGrid) {
                                detectDragGestures { change, drag ->
                                    change.consume()
                                    val dw = drag.x / w.toPx().coerceAtLeast(1f)
                                    val dh = drag.y / h.toPx().coerceAtLeast(1f)
                                    onResize(node.id, if (snapToGrid) (dw * 20f).roundToInt() / 20f else dw,
                                        if (snapToGrid) (dh * 10f).roundToInt() / 10f else dh)
                                }
                            }, contentAlignment = Alignment.Center) {
                            Text("↘", color = Color(0xFF17202C), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (definition.components.isEmpty()) Text("Add components in Studio", color = Color.White.copy(alpha = .65f), fontSize = 12.sp)
    }
}

@Composable
private fun HomeComponentRenderer(node: HomeComponent, modifier: Modifier = Modifier) {
    if (node.hidden) return
    val tint = Color(node.colorArgb.toInt()).copy(alpha = node.alpha)
    when (node.type) {
        "text" -> Box(modifier.padding(node.padding.dp), contentAlignment = Alignment.CenterStart) { Text(node.text, color = tint, fontSize = node.size.coerceIn(8f, 96f).sp, maxLines = 8,
            textAlign = when (node.alignment) { "center" -> TextAlign.Center; "end" -> TextAlign.End; else -> TextAlign.Start }) }
        "shape" -> Box(modifier.padding(node.padding.dp).background(tint, RoundedCornerShape(10.dp)))
        "spacer" -> Spacer(modifier)
        "image" -> HomeImageNode(node, modifier)
        "container", "row", "column", "box" -> {
            val contentModifier = modifier.padding(node.padding.dp).background(tint.copy(alpha = (node.alpha * 0.22f).coerceIn(0f, 1f)), RoundedCornerShape(10.dp))
            when (node.layout.ifBlank { if (node.type == "row") "row" else "column" }) {
                "row" -> Row(contentModifier, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) { node.children.forEach { HomeComponentRenderer(it, Modifier.weight(1f).fillMaxHeight()) } }
                "box" -> BoxWithConstraints(contentModifier) { node.children.forEach { child ->
                    Box(Modifier.offset(x = maxWidth * child.x, y = maxHeight * child.y).fillMaxWidth(child.width).fillMaxHeight(child.height)) {
                        HomeComponentRenderer(child, Modifier.fillMaxSize())
                    }
                } }
                else -> Column(contentModifier, verticalArrangement = Arrangement.spacedBy(4.dp)) { node.children.forEach { HomeComponentRenderer(it, Modifier.fillMaxWidth().weight(1f, fill = false)) } }
            }
        }
    }
}

@Composable
private fun HomeImageNode(node: HomeComponent, modifier: Modifier = Modifier) {
    val uri = remember(node.imageUri) { runCatching { Uri.parse(node.imageUri) }.getOrNull() }
    if (uri != null && node.imageUri.isNotBlank()) {
        AndroidView(modifier = modifier, factory = { ImageView(it).apply { scaleType = ImageView.ScaleType.CENTER_CROP } }, update = { view ->
            runCatching { view.setImageURI(uri) }.onFailure { view.setImageDrawable(null) }
        })
    } else Box(modifier.background(Color(0x334A90E2), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
        Text("Image · choose URI", color = Color.White.copy(alpha = .7f), fontSize = 11.sp)
    }
}


private fun findComponent(nodes: List<HomeComponent>, id: String?): HomeComponent? {
    if (id == null) return null
    for (node in nodes) { if (node.id == id) return node; findComponent(node.children, id)?.let { return it } }
    return null
}
private fun updateComponent(nodes: List<HomeComponent>, id: String, transform: (HomeComponent) -> HomeComponent): List<HomeComponent> = nodes.map { node ->
    if (node.id == id) transform(node) else node.copy(children = updateComponent(node.children, id, transform))
}
private fun flattenComponents(nodes: List<HomeComponent>): List<HomeComponent> = nodes.flatMap { listOf(it) + flattenComponents(it.children) }
private fun removeComponent(nodes: List<HomeComponent>, id: String): List<HomeComponent> = nodes.filterNot { it.id == id }.map { it.copy(children = removeComponent(it.children, id)) }

/** Reorder a node among siblings at any depth, not only at the root. */
private fun moveComponent(nodes: List<HomeComponent>, id: String, delta: Int): List<HomeComponent> {
    val index = nodes.indexOfFirst { it.id == id }
    if (index >= 0) {
        val target = (index + delta).coerceIn(0, nodes.lastIndex)
        if (target == index) return nodes
        return nodes.toMutableList().also { list ->
            val item = list.removeAt(index)
            list.add(target, item)
        }
    }
    return nodes.map { it.copy(children = moveComponent(it.children, id, delta)) }
}

@Composable
fun HomeWidgetStudio(initial: HomeWidgetDefinition = HomeWidgetDefinition(type = "custom", name = "My Widget"), onCancel: () -> Unit, onSave: (HomeWidgetDefinition) -> Unit) {
    var background by remember { mutableLongStateOf(initial.backgroundArgb) }
    var foreground by remember { mutableLongStateOf(initial.foregroundArgb) }
    var use24 by remember { mutableStateOf(initial.use24Hour) }
    var showDate by remember { mutableStateOf(initial.showDate) }
    var scale by remember { mutableFloatStateOf(initial.fontScale) }
    var customMode by remember { mutableStateOf(initial.type == "custom") }
    var nodes by remember { mutableStateOf(initial.components) }
    var selectedId by remember { mutableStateOf(initial.components.firstOrNull()?.id) }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    val undoStack = remember { mutableStateListOf<List<HomeComponent>>() }
    val redoStack = remember { mutableStateListOf<List<HomeComponent>>() }
    var historyReady by remember { mutableStateOf(false) }
    var previousNodes by remember { mutableStateOf(initial.components) }
    LaunchedEffect(nodes) {
        kotlinx.coroutines.delay(250)
        if (!historyReady) {
            previousNodes = nodes
            historyReady = true
        } else if (nodes != previousNodes) {
            undoStack.add(previousNodes)
            while (undoStack.size > 40) undoStack.removeAt(0)
            previousNodes = nodes
            redoStack.clear()
        }
    }
    var snapToGrid by remember { mutableStateOf(true) }
    val studioContext = LocalContext.current
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && selectedId != null) {
            runCatching { studioContext.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            nodes = updateComponent(nodes, selectedId!!) { it.copy(imageUri = uri.toString()) }
        }
    }
    val selected = findComponent(nodes, selectedId)
    val backgrounds = listOf(0xFF253247L, 0xFF202124L, 0xFF354B3AL, 0xFF5A3544L, 0xFFE8EAF0L)
    val foregrounds = listOf(0xFFFFFFFFL, 0xFFB8D7FFL, 0xFFFFD59AL, 0xFF202124L)
    Surface(Modifier.fillMaxSize(), color = Color(0xF510131A)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Widget Studio", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onCancel) { Text("CLOSE") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !customMode, onClick = { customMode = false }, label = { Text("Clock") })
                FilterChip(selected = customMode, onClick = { customMode = true }, label = { Text("Visual builder") })
            }
            if (!customMode) {
                Text("CLOCK · LIVE PREVIEW", color = Color(0xFF9AA5B5), fontSize = 11.sp)
                Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                    HomeClockWidget(initial.copy(backgroundArgb = background, foregroundArgb = foreground, use24Hour = use24, showDate = showDate, fontScale = scale), Modifier.width(250.dp).height(100.dp))
                }
                Text("Background", color = Color.White); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { backgrounds.forEach { c -> ColorSwatch(c, background == c) { background = c } } }
                Text("Text color", color = Color.White); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { foregrounds.forEach { c -> ColorSwatch(c, foreground == c) { foreground = c } } }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("24-hour format", color = Color.White); Switch(use24, { use24 = it }) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Show date", color = Color.White); Switch(showDate, { showDate = it }) }
                Text("Font size · ${(scale * 100).toInt()}%", color = Color.White); Slider(scale, { scale = it }, valueRange = 0.7f..1.5f)
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("COMPONENT TREE · ${flattenComponents(nodes).size}/80", color = Color(0xFF9AA5B5), fontSize = 11.sp)
                    Row {
                        TextButton(enabled = undoStack.isNotEmpty(), onClick = {
                            if (undoStack.isNotEmpty()) {
                                redoStack.add(nodes)
                                nodes = undoStack.removeAt(undoStack.lastIndex)
                                previousNodes = nodes
                            }
                        }) { Text("UNDO") }
                        TextButton(enabled = redoStack.isNotEmpty(), onClick = {
                            if (redoStack.isNotEmpty()) {
                                undoStack.add(nodes)
                                nodes = redoStack.removeAt(redoStack.lastIndex)
                                previousNodes = nodes
                            }
                        }) { Text("REDO") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("text", "image", "shape", "row", "column", "box", "spacer").forEach { type ->
                        OutlinedButton(onClick = { val n = HomeComponent(type = type, layout = type.takeIf { it in setOf("row", "column", "box") } ?: "column", text = if (type == "text") "Hello HOME" else "", y = (nodes.size * 0.22f).coerceAtMost(0.78f)); nodes = (nodes + n).take(80); selectedId = n.id }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) { Text(type.uppercase(), fontSize = 9.sp) }
                    }
                }
                Box(Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 320.dp).background(Color(0xFF171D27), RoundedCornerShape(12.dp)).padding(10.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("CANVAS · drag to move · corner to resize", color = Color(0xFF9AA5B5), fontSize = 9.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) { Text("Snap", color = Color.White, fontSize = 10.sp); Switch(snapToGrid, { snapToGrid = it }) }
                        }
                        HomeCustomWidget(initial.copy(type = "custom", backgroundArgb = background, components = nodes), Modifier.fillMaxWidth().height(220.dp), editing = true,
                            selectedId = selectedId, snapToGrid = snapToGrid, onSelect = { selectedId = it },
                            onMove = { id, dx, dy -> nodes = updateComponent(nodes, id) { it.copy(x = (it.x + dx).coerceIn(0f, 0.95f), y = (it.y + dy).coerceIn(0f, 0.95f)) } },
                            onResize = { id, dw, dh -> nodes = updateComponent(nodes, id) { it.copy(width = (it.width + dw).coerceIn(0.08f, 1f), height = (it.height + dh).coerceIn(0.08f, 1f)) } })
                        Divider(color = Color(0x334A5568))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Layers · multi-select", color = Color.White, fontWeight = FontWeight.SemiBold)
                            TextButton(enabled = selectedIds.isNotEmpty(), onClick = {
                                val deleting = selectedIds
                                deleting.forEach { id -> nodes = removeComponent(nodes, id) }
                                if (selectedId != null && selectedId in deleting) selectedId = flattenComponents(nodes).firstOrNull()?.id
                                selectedIds = emptySet()
                            }) { Text("DELETE ${selectedIds.size}") }
                        }
                        flattenComponents(nodes).forEach { node ->
                            Row(Modifier.fillMaxWidth().background(if (node.id == selectedId || node.id in selectedIds) Color(0x334A90E2) else Color.Transparent, RoundedCornerShape(6.dp)).clickable { selectedId = node.id }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = node.id in selectedIds, onCheckedChange = { checked -> selectedIds = if (checked) selectedIds + node.id else selectedIds - node.id }, modifier = Modifier.size(28.dp))
                                Text("${node.type}: ${node.text.ifBlank { node.id.take(6) }}", color = if (node.hidden) Color(0xFF788394) else Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                                TextButton(onClick = { nodes = updateComponent(nodes, node.id) { it.copy(hidden = !it.hidden) } }) { Text(if (node.hidden) "SHOW" else "HIDE") }
                                TextButton(onClick = { nodes = updateComponent(nodes, node.id) { it.copy(locked = !it.locked) } }) { Text(if (node.locked) "UNLOCK" else "LOCK") }
                                TextButton(onClick = { nodes = moveComponent(nodes, node.id, -1) }) { Text("↑") }
                                TextButton(onClick = { nodes = moveComponent(nodes, node.id, 1) }) { Text("↓") }
                                TextButton(onClick = { nodes = removeComponent(nodes, node.id); selectedIds = selectedIds - node.id; if (selectedId == node.id) selectedId = nodes.firstOrNull()?.id }) { Text("×") }
                            }
                        }
                    }
                }
                if (selected != null) {
                    Text("Selected: ${selected.type}", color = Color.White)
                    if (selected.type in setOf("row", "column", "box", "container")) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("text", "shape", "image").forEach { childType ->
                                TextButton(onClick = {
                                    val child = HomeComponent(type = childType, text = if (childType == "text") "Nested text" else "")
                                    nodes = updateComponent(nodes, selected.id) { it.copy(children = (it.children + child).take(20)) }
                                    selectedId = child.id
                                }) { Text("+ $childType") }
                            }
                        }
                        Text("Container layout", color = Color.White)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("row", "column", "box").forEach { mode -> FilterChip(selected = selected.layout == mode, onClick = { nodes = updateComponent(nodes, selected.id) { it.copy(layout = mode) } }, label = { Text(mode.uppercase()) }) } }
                    }
                    if (selected.type == "text" || selected.type == "container") {
                        OutlinedTextField(value = selected.text, onValueChange = { value -> nodes = updateComponent(nodes, selected.id) { it.copy(text = value.take(500)) } }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Text") })
                    }
                    if (selected.type == "image") {
                        TextButton(onClick = { imagePicker.launch(arrayOf("image/*")) }) { Text("CHOOSE IMAGE") }
                        Text(selected.imageUri.ifBlank { "No image selected" }, color = Color(0xFF9AA5B5), fontSize = 9.sp, maxLines = 1)
                    }
                    Text("Font / element size · ${selected.size.toInt()} dp", color = Color.White)
                    Slider(selected.size, { v -> nodes = updateComponent(nodes, selected.id) { it.copy(size = v) } }, valueRange = 8f..120f)
                    Text("Width · ${(selected.width * 100).toInt()}%", color = Color.White)
                    Slider(selected.width, { v -> nodes = updateComponent(nodes, selected.id) { it.copy(width = v) } }, valueRange = 0.1f..1f)
                    Text("Height · ${(selected.height * 100).toInt()}%", color = Color.White)
                    Slider(selected.height, { v -> nodes = updateComponent(nodes, selected.id) { it.copy(height = v) } }, valueRange = 0.1f..1f)
                    Text("X · ${(selected.x * 100).toInt()}%", color = Color.White)
                    Slider(selected.x, { v -> nodes = updateComponent(nodes, selected.id) { it.copy(x = v) } }, valueRange = 0f..0.95f)
                    Text("Y · ${(selected.y * 100).toInt()}%", color = Color.White)
                    Slider(selected.y, { v -> nodes = updateComponent(nodes, selected.id) { it.copy(y = v) } }, valueRange = 0f..0.95f)
                    Text("Opacity · ${(selected.alpha * 100).toInt()}%", color = Color.White)
                    Slider(selected.alpha, { v -> nodes = updateComponent(nodes, selected.id) { it.copy(alpha = v) } }, valueRange = 0f..1f)
                    Text("Padding · ${selected.padding} dp", color = Color.White)
                    Slider(selected.padding.toFloat(), { v -> nodes = updateComponent(nodes, selected.id) { it.copy(padding = v.toInt()) } }, valueRange = 0f..48f, steps = 47)
                    if (selected.type == "text") {
                        Text("Text alignment", color = Color.White)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("start", "center", "end").forEach { mode -> FilterChip(selected = selected.alignment == mode, onClick = { nodes = updateComponent(nodes, selected.id) { it.copy(alignment = mode) } }, label = { Text(mode.uppercase()) }) } }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { foregrounds.forEach { c -> ColorSwatch(c, selected.colorArgb == c) { nodes = updateComponent(nodes, selected.id) { it.copy(colorArgb = c) } } } }
                }
                Text("Background", color = Color.White); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { backgrounds.forEach { c -> ColorSwatch(c, background == c) { background = c } } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                Button(onClick = { onSave(initial.copy(type = if (customMode) "custom" else "clock", name = if (customMode) "My Widget" else "Clock", backgroundArgb = background, foregroundArgb = foreground, use24Hour = use24, showDate = showDate, fontScale = scale, components = if (customMode) nodes else emptyList())) }, modifier = Modifier.weight(1f)) { Text("Save widget") }
            }
        }
    }
}

@Composable
private fun ColorSwatch(color: Long, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = Modifier.size(30.dp), shape = RoundedCornerShape(50), color = Color(color.toInt()),
        border = if (selected) androidx.compose.foundation.BorderStroke(3.dp, Color(0xFF8AB4F8)) else null) {}
}
