package com.home.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import android.content.Context
import android.net.Uri
import java.security.MessageDigest
import java.util.Base64

/** Portable HOME workspace package. Android AppWidgetHost IDs are intentionally excluded. */
object Homepack {
    private const val MAX_ARCHIVE_BYTES = 12 * 1024 * 1024
    private const val MAX_ENTRIES = 256
    private const val MAX_ENTRY_BYTES = 2 * 1024 * 1024

    fun write(output: OutputStream, widgets: JSONArray, shortcuts: JSONArray, assets: Map<String, ByteArray> = emptyMap(), canvas: JSONObject = JSONObject()) {
        val manifest = JSONObject()
            .put("format", "homepack")
            .put("formatVersion", 3)
            .put("app", "HOME")
            .put("createdAt", System.currentTimeMillis())
            .put("portableWidgetCount", widgets.length())
            .put("shortcutCount", shortcuts.length())
            .put("assetCount", assets.size)
            .put("nativeAndroidWidgets", "not-exported-device-bound")
        val workspace = JSONObject()
            .put("schemaVersion", 3)
            .put("widgets", widgets)
            .put("shortcuts", shortcuts)
            .put("canvas", JSONObject(canvas.toString()))
        require(assets.size <= 200 && assets.values.sumOf { it.size.toLong() } <= 10L * 1024 * 1024) { "Homepack assets exceed limits" }
        ZipOutputStream(output.buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("manifest.json")); zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8)); zip.closeEntry()
            zip.putNextEntry(ZipEntry("workspace.json")); zip.write(workspace.toString(2).toByteArray(Charsets.UTF_8)); zip.closeEntry()
            assets.toSortedMap().forEach { (name, bytes) ->
                require(name.matches(Regex("[a-f0-9]{64}\\.img")) && bytes.size <= MAX_ENTRY_BYTES) { "Invalid asset" }
                zip.putNextEntry(ZipEntry("assets/$name")); zip.write(bytes); zip.closeEntry()
            }
        }
    }

    /** Rewrites granted content URIs to package-local asset references and collects their bytes. */
    fun preparePortableWidgets(context: Context, widgets: JSONArray): Map<String, ByteArray> {
        val assets = linkedMapOf<String, ByteArray>()
        fun walk(nodes: JSONArray) {
            for (i in 0 until nodes.length()) {
                val node = nodes.getJSONObject(i)
                val raw = node.optString("imageUri")
                if (raw.isNotBlank() && !raw.startsWith("assets/")) {
                    val bytes = runCatching { context.contentResolver.openInputStream(Uri.parse(raw))?.use { it.readBytesBounded(MAX_ENTRY_BYTES) } }.getOrNull()
                    if (bytes != null && runCatching { GraphicsFormats.requireSupportedImage(bytes) }.isSuccess) {
                        val hash = sha256Hex(bytes) + ".img"
                        assets[hash] = bytes
                        node.put("imageUri", "assets/$hash")
                    } else if (bytes != null) {
                        // Unsupported format: do not leak the device-local URI into the shared pack.
                        node.put("imageUri", "")
                    }
                }
                walk(node.optJSONArray("children") ?: JSONArray())
            }
        }
        for (i in 0 until widgets.length()) walk(widgets.getJSONObject(i).optJSONArray("components") ?: JSONArray())
        return assets
    }

    fun restorePortableAssets(context: Context, workspace: JSONObject) {
        val assetBytes = workspace.optJSONObject("_assets") ?: return
        val assetDir = java.io.File(context.filesDir, "homepack_assets").apply { mkdirs() }
        fun walk(nodes: JSONArray) {
            for (i in 0 until nodes.length()) {
                val node = nodes.getJSONObject(i)
                val ref = node.optString("imageUri")
                if (ref.startsWith("assets/")) {
                    val name = ref.removePrefix("assets/")
                    val encoded = assetBytes.optString(name)
                    if (name.matches(Regex("[a-f0-9]{64}\\.img")) && encoded.isNotBlank()) {
                        val file = java.io.File(assetDir, name)
                        runCatching { file.writeBytes(Base64.getDecoder().decode(encoded)) }
                        if (file.exists()) node.put("imageUri", Uri.fromFile(file).toString())
                    }
                }
                walk(node.optJSONArray("children") ?: JSONArray())
            }
        }
        val widgets = workspace.optJSONArray("widgets") ?: JSONArray()
        for (i in 0 until widgets.length()) walk(widgets.getJSONObject(i).optJSONArray("components") ?: JSONArray())
        workspace.remove("_assets")
    }

    fun read(input: InputStream): JSONObject {
        val entries = linkedMapOf<String, ByteArray>()
        var total = 0
        ZipInputStream(input.buffered()).use { zip ->
            var count = 0
            while (true) {
                val entry = zip.nextEntry ?: break
                count++
                require(count <= MAX_ENTRIES) { "Too many files in Homepack" }
                val name = entry.name
                require(!entry.isDirectory && !name.startsWith("/") && !name.contains("\\") &&
                    name.split('/').none { it == ".." || it.isBlank() }) { "Unsafe Homepack path" }
                require(name == "manifest.json" || name == "workspace.json" || (name.startsWith("assets/") && name.removePrefix("assets/").matches(Regex("[a-f0-9]{64}\\.img")))) { "Unsupported Homepack entry: $name" }
                val bytes = zip.readBytesBounded(MAX_ENTRY_BYTES)
                if (name.startsWith("assets/")) {
                    require(sha256Hex(bytes) + ".img" == name.removePrefix("assets/")) { "Asset hash mismatch: $name" }
                    GraphicsFormats.requireSupportedImage(bytes)
                }
                total += bytes.size
                require(total <= MAX_ARCHIVE_BYTES) { "Homepack is too large" }
                if (name == "manifest.json" || name == "workspace.json") entries[name] = bytes
                else if (name.startsWith("assets/")) entries[name] = bytes
                zip.closeEntry()
            }
        }
        val manifest = JSONObject(String(entries["manifest.json"] ?: error("Missing manifest.json"), Charsets.UTF_8))
        require(manifest.optString("format") == "homepack") { "Not a HOME Homepack" }
        require(manifest.optInt("formatVersion") in 1..3) { "Unsupported Homepack version" }
        val workspace = JSONObject(String(entries["workspace.json"] ?: error("Missing workspace.json"), Charsets.UTF_8))
        require(workspace.optInt("schemaVersion") in 1..3) { "Unsupported workspace schema" }
        val assetIndex = JSONObject()
        entries.filterKeys { it.startsWith("assets/") }.forEach { (path, bytes) -> assetIndex.put(path.removePrefix("assets/"), Base64.getEncoder().encodeToString(bytes)) }
        if (assetIndex.length() > 200) error("Too many assets")
        workspace.put("_assets", assetIndex)
        val canvas = workspace.optJSONObject("canvas") ?: JSONObject()
        val canvasMode = canvas.optString("mode", "PAGED")
        require(canvasMode in setOf("PAGED", "WIDE", "FREEFORM")) { "Unsupported canvas mode" }
        require(canvas.optInt("widthScreens", 3) in 1..5) { "Invalid canvas width" }
        require(canvas.optInt("heightScreens", 1) in 1..3) { "Invalid canvas height" }
        workspace.put("canvas", canvas)
        val widgets = workspace.optJSONArray("widgets") ?: JSONArray()
        require(widgets.length() <= 100) { "Too many widgets" }
        val seenIds = mutableSetOf<String>()
        for (i in 0 until widgets.length()) {
            val w = widgets.getJSONObject(i)
            require(w.optString("type") in setOf("clock", "custom")) { "Unsupported widget type: ${w.optString("type")}" }
            val components = w.optJSONArray("components") ?: JSONArray()
            require(components.length() <= 80) { "Too many widget components" }
            val componentCount = intArrayOf(0)
            fun validateNodes(nodes: JSONArray, depth: Int) {
                require(depth <= 6) { "Component nesting too deep" }
                for (j in 0 until nodes.length()) {
                    val component = nodes.getJSONObject(j)
                    componentCount[0]++
                    require(componentCount[0] <= 80) { "Too many nested components" }
                    require(component.optString("type") in setOf("text", "shape", "spacer", "container", "image", "row", "column", "box")) { "Unsupported component type" }
                    require(component.optString("text").length <= 500 && component.optString("imageUri").length <= 2048) { "Component data too large" }
                    require(component.optDouble("size", 18.0) in 4.0..240.0) { "Invalid component size" }
                    require(component.optDouble("width", 0.9) in 0.05..1.0 && component.optDouble("height", 0.2) in 0.05..1.0) { "Invalid component bounds" }
                    validateNodes(component.optJSONArray("children") ?: JSONArray(), depth + 1)
                }
            }
            validateNodes(components, 0)
            val id = w.optString("id")
            require(id.isNotBlank() && id.length <= 80 && seenIds.add(id)) { "Missing or duplicate widget ID" }
            require(w.optInt("page", 0) in 0..4) { "Invalid widget page" }
            require(w.optDouble("x", -1.0) in 0.0..1.0 && w.optDouble("y", -1.0) in 0.0..1.0) { "Invalid widget position" }
            require(w.optInt("w", 220) in 140..420 && w.optInt("h", 112) in 80..260) { "Invalid widget dimensions" }
            require(w.optDouble("scale", 1.0) in 0.7..1.5) { "Invalid widget font scale" }
        }
        val shortcuts = workspace.optJSONArray("shortcuts") ?: JSONArray()
        require(shortcuts.length() <= 500) { "Too many shortcuts" }
        for (i in 0 until shortcuts.length()) {
            val shortcut = shortcuts.getJSONObject(i)
            require(shortcut.optString("pkg").isNotBlank() && shortcut.optString("pkg").length <= 255) { "Invalid shortcut package" }
            require(shortcut.optInt("page", 0) in 0..4) { "Invalid shortcut page" }
            require(shortcut.optDouble("x", -1.0) in 0.0..1.0 && shortcut.optDouble("y", -1.0) in 0.0..1.0) { "Invalid shortcut position" }
        }
        return workspace
    }

    private fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    private fun InputStream.readBytesBounded(limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var size = 0
        while (true) {
            val n = read(buffer)
            if (n < 0) break
            size += n
            require(size <= limit) { "Homepack entry is too large" }
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }
}
