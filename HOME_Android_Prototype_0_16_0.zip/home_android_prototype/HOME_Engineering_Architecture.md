# HOME — Engineering Architecture

**Document status:** current architecture and implementation audit  
**Code baseline:** HOME 0.16.0 (incremental extension of device-tested 0.15.1)  
**Technology:** Kotlin, Android SDK, Jetpack Compose, Room, Kotlin coroutines

## 1. Architecture goals

- Keep the launcher usable while editor and workspace capabilities evolve.
- Keep portable workspace data separate from Android system-owned widget IDs.
- Use declarative, bounded content for HOME Widgets, Homepacks, and future AI-generated layouts.
- Preserve old user data while gradually moving from legacy storage to a canonical repository.
- Prefer subsystem-level changes; do not introduce a global model or storage migration without an explicit plan.

## 2. Current project structure

| Area | Current location | Actual responsibility / status |
|---|---|---|
| Android launcher shell | `MainActivity.kt` | Activity, launcher discovery, gestures, workspace UI, app placements, Homepack entry points, native widget host integration |
| HOME Widget model/editor/renderer | `HomeWidgets.kt` | `HomeComponent`, `HomeWidgetDefinition`, JSON serialization, custom renderer, clock, Studio, component tree/layers |
| Homepack | `Homepack.kt` | ZIP read/write, schema validation, image asset portability |
| Native widget adapter | `NativeWidgets.kt` | `AppWidgetHost`, native widget placement model, preference persistence |
| Spatial model foundation | `core/model/WorkspaceModels.kt`, `WorkspaceCanvas.kt` | Typed workspace/page/element/geometry and canvas/viewport data classes; not yet the active unified workspace store |
| Layout foundation | `core/layout/LayoutResolver.kt` | Converts element geometry relative to a viewport; not yet the sole layout path used by the UI |
| Room storage | `data/RoomWorkspaceStore.kt`, `WorkspaceRepository.kt` | Database, migration, legacy preference mirroring, typed snapshot reads |

The current app is still a compact prototype with several concerns located in `MainActivity.kt` and `HomeWidgets.kt`. The package structure is a foundation, not evidence of fully separated Gradle modules.

## 3. Dependency and boundary direction

Target boundaries:

- `core-model`: platform-independent workspace and object definitions.
- `workspace-engine`: geometry, snapping, hit testing, grouping, viewport and layout resolution.
- `workspace-renderer`: renders immutable workspace snapshots; should not own persistence.
- `app-discovery`: Android package discovery and launch operations.
- `native-widget-host`: Android `AppWidgetHost` adapter; owns device-local IDs and provider lifecycle.
- `home-widget-runtime`: safe declarative HOME Widget renderer and lifecycle.
- `widget-studio`: editor use cases and UI over shared models.
- `homepack`: versioned import/export and migrations.
- `persistence`: repository contracts and Room implementation.
- `design-system`: shared visual components.

These are logical boundaries. Do not create empty Gradle modules merely to imitate the diagram. Extract modules when stable contracts and real dependency boundaries exist.

## 4. Canonical workspace model — target

The intended shared document includes:

- `Workspace`: identity, active page, canvas settings, pages.
- `Page`: identity, order, grid configuration, objects.
- `CanvasObject`: stable UUID, type, geometry, layer/order, visibility, lock state, properties.
- `Geometry`: x/y/width/height, coordinate unit, anchor, rotation, scale, constraints.
- `Layer`: ordering, visibility, lock, grouping metadata.
- `WidgetDefinition`: reusable component tree and declarative configuration.
- `WidgetInstance`: placed instance and state reference.
- `NativeWidgetInstance`: provider reference and local placement; system ID is local-only.
- `AppletDefinition` and `InteractionBinding`: future bounded applet behavior and typed interactions.
- `Asset`: content-addressed portable resource.

Use stable UUIDs for portable identities. Keep device-local Android identifiers out of portable documents. Maintain explicit schema versions and migrations.

### Current reality

`Workspace`, `Page`, `Element`, `Geometry`, `WorkspaceCanvas`, and `CanvasViewport` data classes exist. However, the launcher UI still uses separate preference-backed records for app placements, HOME Widgets, native widget placements, and page/canvas settings. The typed spatial model is not yet the single source of truth.

## 5. Coordinates and layout

Target coordinate units:

- `RELATIVE`: normalized to a page/canvas viewport.
- `DP`: density-independent physical size.
- `GRID`: logical grid coordinates.

GRID and FREE must coexist in one model. Layout resolution should account for viewport offset, screen/page dimensions, anchor, scale, rotation, and safe areas. Snapping and hit testing belong in the workspace engine, not in individual UI widgets.

Current implementation:
- App placements and HOME Widget components use normalized x/y/width/height values.
- Grid snapping is currently implemented in UI gesture code.
- Wide mode composes page-local positions into a horizontal surface.
- `LayoutResolver` and canvas viewport classes exist but are not the complete UI rendering path.
- Current width is bounded to 1–5 horizontal screens; no infinite or vertical canvas interaction exists.

## 6. Persistence and migration

### Current source of truth

`SharedPreferences` file `home_workspace` remains authoritative for the active UI. JSON arrays and scalar keys store app placements, HOME Widgets, native widget placements, active page, grid mode, wide mode, and page count.

Room database `home_workspace.db` is a mirror/recovery store:
- schema version 2;
- `workspace_records` retains legacy key/value records;
- normalized tables store metadata, pages, shortcuts, HOME Widgets, and native widget placements;
- migration 1→2 creates normalized tables;
- `RoomWorkspaceStore` mirrors preference records and calls `WorkspaceRepository.syncFromLegacy` transactionally;
- `WorkspaceRepository.loadSnapshot` reads typed records, but the active UI does not use it as its read path.

HOME 0.15.1 corrects the Room mirror to create the configured 1–5 page records instead of always creating three. It does not switch persistence authority or change the Room schema.

### Safe migration direction

1. Define repository interfaces around the current data shapes.
2. Add parity tests comparing preference and Room snapshots.
3. Introduce a one-time, idempotent migration with rollback/recovery behavior.
4. Switch reads and writes for one data family at a time.
5. Keep legacy keys until migration is proven and a later cleanup is approved.

Do not delete or rewrite legacy data as part of a speculative migration.

## 7. HOME Widget runtime and Studio

Current `HomeComponent` is a declarative tree with allowlisted types: `text`, `shape`, `spacer`, `container`, `image`, `row`, `column`, `box`. The importer limits total nodes to 80 and nesting depth to 6. Text, image reference, geometry, alpha, and other fields are bounded.

0.14.0 introduced optional `hidden` and `locked` component flags. Missing fields deserialize to `false`, preserving older Homepack compatibility. Hidden nodes are omitted by the renderer; locked nodes cannot be dragged/resized in the component canvas. The layer tree can still select and change their state. Component order is used as rendering z-order for top-level components; nested siblings render in their tree order.

0.15.1 carries this behavior forward. 0.16.0 adds workspace-level visibility and placement-lock state for app shortcuts, HOME Widgets, and native Android Widgets. The optional `workspace_layers` JSON preference stores object-keyed flags. Portable app and HOME Widget states are included in the existing Homepack canvas metadata; native widget state remains device-local. Duplicate HOME Widget IDs are remapped during import. A post-release audit found that the 0.15.1 `loadHomeWidgets` path still clamped stored page indices to 0–2 even though import and Room accepted 0–4; 0.16.0 corrects the loader to preserve indices 0–4.

Limitations:
- Workspace-level controls provide visibility and placement locking, not a shared z-order, grouping, or transform engine.
- Direct manipulation is strongest for top-level components; nested content is mainly managed through the tree and property controls.
- No general-purpose applet runtime or arbitrary scripting is allowed.

## 8. Native Android Widgets

`HomeAppWidgetHost` uses a stable host ID. Android widget IDs and provider state are device-bound. Placement records include local ID, page, x/y, width, and height. The host and UI must handle bind/configure, start/stop listening, resize, removal, provider absence, and restore paths. Homepack must never pretend a local `appWidgetId` is portable.

## 9. Homepack format and security

Current writer:
- ZIP entries `manifest.json`, `workspace.json`, and optional `assets/<sha256>.img`.
- format version 3; workspace schema version 3.
- portable HOME Widget definitions, shortcut placements, and canvas metadata.
- native Android widget IDs are intentionally excluded.

Current reader:
- accepts format/schema versions 1–3;
- bounds entry count, individual entry size, total uncompressed payload size, component count/depth, dimensions, text lengths, and asset count;
- rejects unsafe paths and unsupported entry names;
- validates content-addressed asset hashes and supported image formats;
- validates widget and shortcut page indices against 0–4.

Known hardening opportunities:
- reject duplicate ZIP entry names instead of silently retaining the last occurrence;
- validate component IDs for uniqueness, not only widget IDs;
- validate all numeric fields and optional booleans consistently;
- avoid unbounded in-memory base64 expansion when importing large packs;
- make schema migrations explicit rather than relying only on optional defaults.

## 10. AI Studio and applets — target safety model

AI output and Homepack content are untrusted data. The pipeline must be:

`external model / API / pasted text → structured extraction → schema validation → capability validation → preview → Homepack import`.

No dynamic code execution. Applets should use a bounded declarative graph/runtime with typed inputs, allowlisted actions, explicit capabilities, execution budgets, and cycle validation.

## 11. Build and compatibility constraints

- Android application, Kotlin, Jetpack Compose.
- JDK 17; compileSdk 35; minSdk 29; targetSdk 35.
- Android Gradle Plugin 8.7.3; Gradle 8.9 in the checked-in CI workflow; Kotlin 2.0.21; Compose BOM 2024.12.01; Room 2.6.1.
- No dependency or toolchain changes are part of 0.16.0.
- Manifest must retain two separate activity filters: `MAIN+HOME+DEFAULT` and `MAIN+LAUNCHER`, `singleTask`, launcher icons, `REQUEST_DELETE_PACKAGES`, and `queries` for `MAIN+LAUNCHER`.

## 12. Verification gates

- **G1 — package/build:** ZIP integrity, project structure, manifest, Gradle configuration, source checks, then actual Gradle build.
- **G2 — launcher:** default launcher selection, HOME/LAUNCHER entry points, app discovery and launch.
- **G3 — workspace:** page navigation, Wide view, drag/drop, GRID/FREE placement, restart persistence.
- **G4 — native widgets:** picker, bind/configure, render, resize, remove, process restart.
- **G5 — HOME Widgets:** create/edit, nested tree, component hide/show, lock/unlock, order, restart persistence.
- **G5A — workspace layers:** hide/show and placement lock across app shortcuts, HOME Widgets, and native widgets; Homepack round-trip for portable object state.
- **G6 — Homepack:** export/import round trip, old versions, assets, duplicate IDs, invalid archives.
- **G7 — storage:** Room mirror parity, dynamic page count, recovery from empty preferences.
- **G8 — performance/accessibility:** frame pacing, hit testing, large workspaces, labels and touch targets.

A static check is not an APK build. An APK build is not a device test. Report each gate separately.
