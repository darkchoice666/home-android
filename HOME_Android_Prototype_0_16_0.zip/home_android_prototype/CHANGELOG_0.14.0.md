# HOME 0.14.0

## Canvas Layers foundation
- Added persistent hidden and locked states to HOME Widget components.
- Extended component JSON serialization with optional `hidden` and `locked` fields. Older Homepacks remain compatible because missing fields default to `false`.
- Added layer-panel controls to show/hide and lock/unlock components.
- Hidden components are omitted from rendering; locked components cannot be dragged or resized in the widget editor.
- Rendering order now follows component layer order rather than an unrelated size-derived z-index.
- Preserved existing component reorder, delete, multi-select, undo/redo, and widget editing behavior.

## Compatibility and limitations
- No new dependencies or Gradle/plugin version changes.
- No database schema changes.
- Layer controls apply to HOME Widget components. Workspace-wide grouping and cross-widget layers are not included in this release.
- APK build and device testing have not been performed in this environment.
