# HOME 0.13.3

- The app drawer now opens with a swipe up on any workspace page. The APPS button on the home screen is gone outside edit mode.
- In edit mode the APPS button remains: it opens the drawer to add apps to the current page.
- Pressing Back closes the app drawer.
- Swipe up and horizontal page swipes are disabled in edit mode, where drags move elements.

## Known limits
- A swipe that starts on a system (Android) widget may be handled by the widget itself; start from an empty area.
- Closing the drawer by swiping down is not implemented (use CLOSE or Back).

## Verification limits
Source-level changes only. Gradle/APK build and on-device gesture behavior have not been run.
