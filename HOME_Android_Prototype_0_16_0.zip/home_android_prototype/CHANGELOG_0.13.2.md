# HOME 0.13.2

- App-icon long-press menu reworked into a popup anchored to the icon (home screen and app drawer): an action row (App info, Uninstall, and Remove from screen for home-screen icons) followed by the app's own shortcuts (quick actions) when available.
- App shortcuts are read through LauncherApps and are only provided by Android while HOME is selected as the default Home app. Without that, the popup shows only the action row. Up to four shortcuts per app are shown.
- Share action from some system launchers is not included.
- Replaces the simple dialog from 0.13.1.

## Verification limits
Source-level changes only. Gradle/APK build and on-device behavior (popup placement, shortcut launching, uninstall flow) have not been run.
