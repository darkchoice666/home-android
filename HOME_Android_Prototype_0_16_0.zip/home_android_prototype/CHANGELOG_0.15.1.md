# HOME 0.15.1

## Consolidated release from the confirmed 0.13.7 baseline

This release is assembled from the user-confirmed, tested 0.13.7 archive. It selectively ports the source changes present in 0.14.0 and 0.15.0; it is not based on the unverified 0.15.0 archive as a whole.

## Carried forward from 0.14.0 — HOME Widget component layers
- Added persistent `hidden` and `locked` state to HOME Widget components.
- Serialized both fields in component JSON; missing fields in older data default to `false` for backward compatibility.
- Added layer-panel HIDE/SHOW and LOCK/UNLOCK controls.
- Hidden components are not rendered; locked components cannot be dragged or resized on the canvas.
- Rendering order follows component list/layer order.
- Preserved the existing component reorder and editor implementation from the 0.14.0 source change.

## Carried forward from 0.15.0 — page consistency
- HOME Widget restoration accepts page indices 0–4, matching the supported 1–5 page workspace.
- Room mirroring creates the configured page records (1–5) and accounts for the highest page referenced by shortcuts and widgets.
- Active-page metadata is clamped to the mirrored page range.
- SharedPreferences remains the active UI persistence authority; Room remains a mirror/recovery representation.

## Packaging and compatibility
- Restored and retained `CHANGELOG_0.14.0.md`, which was absent from the 0.15.0 archive.
- Retained `CHANGELOG_0.15.0.md` and the product/architecture/roadmap documentation introduced in 0.15.0.
- Started from the 0.13.7 source tree; no global workspace model, Homepack schema, persistence authority, dependencies, plugins, or toolchain changes were made.
- `versionCode` advanced to 24 and `versionName` to `0.15.1`.

## Verification status
- Archive integrity, required project files, manifest requirements, version metadata, and source-level structural checks are checked in the prepared archive.
- Gradle/APK build and physical-device testing have not been performed in this environment.
