# HOME 0.15.0

## Workspace page consistency
- HOME Widgets now restore page indices across the full supported range 0–4.
- Room mirroring now creates the configured 1–5 page records instead of always creating three.
- Room active-page metadata is clamped to the actual mirrored page range.

## HOME Widget component layers
- Carried forward the audited 0.14.0 component visibility and lock state.
- Hidden and locked flags remain optional in serialized component JSON; older data defaults to visible and unlocked.
- Layer tree controls support show/hide and lock/unlock for nested HOME Widget components.
- Hidden components are not rendered; locked components cannot be dragged or resized in the canvas editor.

## Compatibility and scope
- No Room schema change.
- SharedPreferences remains the active UI persistence authority; Room remains a mirror/recovery store.
- No new dependencies, plugins, or toolchain changes.
- No global workspace model migration in this release.
- APK build and physical-device testing are not claimed in this package.
