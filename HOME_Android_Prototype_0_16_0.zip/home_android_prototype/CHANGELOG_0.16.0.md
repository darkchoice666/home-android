# HOME 0.16.0

## Workspace-wide visibility and placement locking
- Added an Edit-mode LAYERS menu for app shortcuts, HOME Widgets, and native Android Widgets.
- Added persistent HIDE/SHOW and LOCK/UNLOCK state for each workspace object.
- Hidden objects are omitted from the workspace rendering but remain available in the LAYERS menu.
- Locked objects cannot be moved; HOME and native widgets also cannot be resized while locked.
- Layer state is stored in the existing `home_workspace` SharedPreferences document and mirrored through the existing Room bridge.
- Portable app and HOME Widget layer states are included in Homepack canvas metadata. Device-local native widget state is intentionally excluded from Homepack.
- Existing Homepacks without layer metadata continue to import with objects visible and unlocked. Duplicate HOME Widget IDs are remapped along with their imported layer state.

## Five-page restoration correction
- Fixed a defect missed in 0.15.1: although import and Room accepted page indices 0–4, `loadHomeWidgets` still clamped persisted records to 0–2. Stored page-4 widgets now remain on page 4 after application restart.

## Compatibility and scope
- Built on the user-confirmed, device-tested HOME 0.15.1 baseline.
- No global workspace model, Homepack format version, persistence authority, dependency, plugin, or toolchain change. Layer metadata is an optional extension to existing canvas metadata.
- Existing launcher gestures, menus, app placement, native widget binding, and default-launcher flow are retained.
- `versionCode` advanced to 25 and `versionName` to `0.16.0`.

## Verification status
- Source-level structural checks, ZIP integrity, required Manifest entries, version metadata, and archive layout are checked in the prepared package.
- Gradle/APK build and physical-device testing have not been performed in the preparation environment.
