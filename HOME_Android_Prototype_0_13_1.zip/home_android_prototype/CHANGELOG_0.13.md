# HOME 0.13.0 — Spatial Workspace Foundation

- Added a versioned workspace-canvas model with PAGED, WIDE and FREEFORM modes.
- Added normalized canvas width/height and viewport models.
- Added canvas-aware layout resolution for elements placed across multiple screen-width pages.
- Added an initial three-screen panoramic rendering mode while preserving existing page-local coordinates and placements.
- Added canvas metadata to Homepack export/import; old Homepacks without canvas metadata remain supported.
- Restored adaptive launcher icon resources and explicit application icon declarations.
- Kept SharedPreferences as the active UI persistence source; Room remains a recovery/mirror store.

## Verification limits

ZIP integrity, XML parsing, manifest/resource assertions, source-level structural checks and Homepack compatibility checks only. Android Gradle build, emulator/device behavior, touch gesture behavior and actual launcher selection have not been verified in this environment.
