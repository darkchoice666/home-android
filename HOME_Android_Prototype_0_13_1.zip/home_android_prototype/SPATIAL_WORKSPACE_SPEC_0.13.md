# HOME Spatial Workspace — implementation note 0.13.0

## Goal

Introduce a backward-compatible spatial canvas foundation without replacing the existing page-local placement model or the working Android/Home widget systems.

## Implemented in 0.13.0

- `WorkspaceCanvas` stores canvas mode (`PAGED`, `WIDE`, `FREEFORM`), width/height in screen units, and screen snapping preference.
- `CanvasViewport` stores viewport position in screen-page units and zoom.
- `LayoutResolver.resolveOnCanvas(...)` converts a page-local element rectangle into viewport pixel coordinates.
- The current launcher UI adds a three-screen `WIDE` presentation mode. In this mode, elements from all three existing pages are composed into one horizontal virtual surface; changing the active page moves the viewport across that surface.
- Existing element coordinates remain page-local normalized values. This avoids destructive migration of existing SharedPreferences data and existing Homepack files.
- Homepack `workspace.json` now has an optional `canvas` object. Packages without it continue to import as `PAGED`.
- Homepack canvas metadata is validated: mode allowlist, width 1–5 screen units, height 1–3 screen units.
- The launcher icon is declared in the manifest and adaptive icon resources are included.

## Current limits (not implemented yet)

- The visible UI currently exposes three populated pages; dynamic page creation and canvas widths beyond three populated pages are not enabled yet.
- `FREEFORM` currently maps to the existing free-positioning mode. It is not a separate infinite canvas renderer.
- Viewport zoom and vertical canvas navigation are data-model capabilities only; no pinch-to-zoom or vertical panning UI is included yet.
- Canvas layers, groups, stickers, photo frames and Applets runtime are not implemented in this release.
- Existing Room tables remain a mirror/recovery store. SharedPreferences remain the active UI persistence authority in this release.

## Compatibility

- Existing `page`, `x`, and `y` values are not rewritten.
- Older Homepack versions without `canvas` metadata remain supported.
- Native Android `appWidgetId` values remain device-local and are not exported.
- The new canvas metadata is additive and does not change the Homepack format/schema version in this step.

## Next implementation steps

1. Move canvas configuration and viewport state behind `WorkspaceRepository`.
2. Replace fixed three-page assumptions with persisted page records and a dynamic canvas width.
3. Introduce a canonical `CanvasObject` model and z-order/layer management.
4. Add Applets as allowlisted declarative objects.
5. Rework Easy/Pro Editor around the canvas object model.
