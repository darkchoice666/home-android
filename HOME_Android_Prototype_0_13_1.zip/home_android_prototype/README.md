# HOME Android Prototype 0.7

Native Android launcher prototype built with Kotlin and Jetpack Compose.

## Included

- Android HOME / DEFAULT intent filter.
- Installed-app discovery, search, launching, and three persisted workspace pages.
- GRID / FREE placement modes and app shortcut edit mode.
- Native Android widgets through `AppWidgetHost` / `AppWidgetManager` (device-bound).
- HOME-owned clock widget with live time/date, 12/24-hour mode, color palettes, and font scaling.
- HOME Visual Builder for custom widgets: text, image, shape, container block, and spacer components.
- Live preview, component selection, text editing, component sizing/color, layer removal and reordering.
- Image selection through Android document picker; persisted read permission is requested for selected image URIs.
- Custom widgets use a declarative, nested component tree with Row, Column, and Box containers.
- Root canvas elements have normalized free-position bounds (x/y/width/height) and opacity.
- Studio provides live preview, drag-to-move for top-level canvas nodes, layer selection, nested child insertion, and controls for bounds, opacity, padding, font size, color, and text alignment.
- Homepack v3 embeds selected image bytes as content-addressed assets and restores them into app-private storage on import.
- Homepack v1/v2 archives remain readable; Android AppWidgetHost IDs remain device-bound and are excluded.

## Homepack v2

A Homepack is a ZIP archive containing `manifest.json`, `workspace.json`, and optional `assets/<sha256>.img` entries. Custom widget trees support `text`, `image`, `shape`, `spacer`, `container`, `row`, `column`, and `box` nodes, up to 80 total nodes per widget and six nesting levels. Asset bytes are limited to 10 MiB total and 2 MiB per image. Paths, entry counts, dimensions, text lengths, node types, and archive size are bounded and validated on import.

Native Android widgets are deliberately excluded: Android `appWidgetId` values are host/device-specific and must be configured again on another device. App shortcuts are restored only when their package is installed on the destination device. Images with an accessible persisted URI are copied into Homepack and restored to app-private storage on the destination device. If the original URI cannot be read, that image remains a non-portable external reference.

## Open and run

1. Open this directory in Android Studio.
2. Use JDK 17 and install Android SDK Platform 35.
3. Allow Gradle to sync.
4. Run on an Android device or emulator.
5. Set HOME as the default launcher when Android asks.

## Known limitations

- Early prototype, not a production launcher.
- The editor's direct-manipulation drag gesture currently moves top-level canvas nodes; nested children are edited through the property controls and container tree.
- Row/Column use equal-weight child allocation; Box uses normalized child bounds. Advanced constraints, alignment presets, clipping, and collision handling remain future work.
- Image files that exceed package limits or whose URI permission has expired are not embedded.
- HOME widget positions use normalized top-left coordinates; resize controls are coarse steps, not collision-aware constraints.
- Data is still stored in SharedPreferences JSON; Room migration and schema migration tooling remain future work.
- Native widget picker/configuration and provider behavior vary by Android version and OEM.
- No APK build or on-device test is claimed in this package. Static archive, manifest, and source-level checks only were performed in the authoring environment.

## Version 0.8.0 — Studio canvas
The visual builder now has a selectable canvas, selection outline, bottom-right resize handle, optional 20×10 alignment grid, and snap-to-grid for drag/resize. These interactions currently apply to top-level nodes; nested nodes remain editable from the layer tree and property inspector. See `CHANGELOG_0.8.md`.

## Version 0.9

The Studio now includes bounded Undo/Redo history, multi-selection and bulk deletion in the Layers panel, recursive sibling reordering for nested components, and center alignment guides on the canvas. The Homepack schema remains unchanged.
See `CHANGELOG_0.9.md` for scope and current limitations.


## 0.10.0 — Room storage foundation

- Added Room database (`home_workspace.db`) and a typed key/value table for workspace records.
- Added an idempotent, non-destructive import from the legacy `home_workspace` SharedPreferences file.
- Added transactional mirroring after workspace, HOME Widget, and native Android widget saves.
- Kept SharedPreferences as the compatibility read path in this migration stage; Room is currently a durable mirror, not yet the canonical source of truth.
- Existing JSON formats and Homepack exports are unchanged.

**Build status:** source changes are prepared, but Gradle/APK build and on-device migration tests have not been run in this environment.


## 0.11.0 — normalized Room workspace model

- Room schema v2 introduces typed tables for workspace metadata, pages, app shortcuts, HOME Widgets, and native Android widget placements.
- `WorkspaceRepository` mirrors legacy JSON arrays and preferences into a normalized Room snapshot in one transaction and provides typed snapshot reads.
- SharedPreferences remains the active UI read/write path in 0.11; Room is not yet the canonical source of truth.
- Homepack remains unchanged; native Android widget IDs remain device-bound.

**Build status:** source-level checks and ZIP integrity only. Gradle/APK build and on-device migration tests have not been run.


## 0.13.0 — Spatial Workspace Foundation

The workspace now has a versioned canvas configuration (PAGED/WIDE/FREEFORM), a viewport model, and canvas-aware layout resolution. The first UI step adds a three-screen panoramic mode while preserving the existing page-local placement format. Homepack now carries optional canvas metadata; older packages remain valid. The adaptive launcher icon is declared in the manifest.
