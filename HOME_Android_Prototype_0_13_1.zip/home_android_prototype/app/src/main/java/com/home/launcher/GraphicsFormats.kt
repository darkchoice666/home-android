package com.home.launcher

import android.graphics.BitmapFactory

/**
 * Stage-1 graphics policy for Homepack assets: raster PNG, JPEG and WebP only.
 * The format is detected from the file bytes, never from a file name or declared type.
 * SVG, GIF, Lottie and anything else are rejected until they get their own stage.
 */
object GraphicsFormats {
    const val MAX_IMAGE_SIDE_PX = 4096

    enum class Kind(val mime: String) { PNG("image/png"), JPEG("image/jpeg"), WEBP("image/webp") }

    fun detect(bytes: ByteArray): Kind? {
        fun at(i: Int): Int = bytes.getOrNull(i)?.toInt()?.and(0xFF) ?: -1
        return when {
            bytes.size >= 8 && at(0) == 0x89 && at(1) == 0x50 && at(2) == 0x4E && at(3) == 0x47 &&
                at(4) == 0x0D && at(5) == 0x0A && at(6) == 0x1A && at(7) == 0x0A -> Kind.PNG
            bytes.size >= 3 && at(0) == 0xFF && at(1) == 0xD8 && at(2) == 0xFF -> Kind.JPEG
            bytes.size >= 12 && at(0) == 0x52 && at(1) == 0x49 && at(2) == 0x46 && at(3) == 0x46 &&
                at(8) == 0x57 && at(9) == 0x45 && at(10) == 0x42 && at(11) == 0x50 -> Kind.WEBP
            else -> null
        }
    }

    /** Throws IllegalArgumentException with a readable message unless [bytes] is an allowed image. */
    fun requireSupportedImage(bytes: ByteArray) {
        requireNotNull(detect(bytes)) { "Unsupported image format (only PNG, JPEG and WebP are allowed)" }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        require(bounds.outWidth in 1..MAX_IMAGE_SIDE_PX && bounds.outHeight in 1..MAX_IMAGE_SIDE_PX) {
            "Image dimensions out of range (max $MAX_IMAGE_SIDE_PX px per side)"
        }
    }
}
