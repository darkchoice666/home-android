package com.home.launcher.core.model

/** Presentation mode for the same portable workspace document. */
enum class CanvasMode { PAGED, WIDE, FREEFORM }

/**
 * Logical canvas configuration. widthScreens is deliberately independent from the
 * number of currently populated pages so the document can grow without changing
 * the coordinate model.
 */
data class WorkspaceCanvas(
    val mode: CanvasMode = CanvasMode.PAGED,
    val widthScreens: Int = 3,
    val heightScreens: Int = 1,
    val snapToScreens: Boolean = true
) {
    fun normalized(): WorkspaceCanvas = copy(
        widthScreens = widthScreens.coerceIn(1, 5),
        heightScreens = heightScreens.coerceIn(1, 3)
    )
}

/** Viewport is expressed in screen-page units, not physical pixels. */
data class CanvasViewport(
    val pageX: Float = 0f,
    val pageY: Float = 0f,
    val zoom: Float = 1f
) {
    fun normalized(maxPageX: Int, maxPageY: Int = 0): CanvasViewport = copy(
        pageX = pageX.coerceIn(0f, maxPageX.coerceAtLeast(0).toFloat()),
        pageY = pageY.coerceIn(0f, maxPageY.coerceAtLeast(0).toFloat()),
        zoom = zoom.coerceIn(0.5f, 2f)
    )
}
