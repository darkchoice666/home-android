package com.home.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.appwidget.AppWidgetManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray
import org.json.JSONObject
import com.home.launcher.data.RoomWorkspaceStore
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private data class LaunchableApp(val label: String, val packageName: String, val activityName: String, val icon: Drawable)
private data class PlacedApp(val packageName: String, val page: Int, val x: Float, val y: Float)

class MainActivity : ComponentActivity() {
    lateinit var widgetHost: HomeAppWidgetHost
        private set
    val nativeWidgets = mutableStateListOf<NativeWidgetPlacement>()
    private var pendingConfigurationWidgetId: Int? = null
    private var pendingWidgetPage: Int = 0

    private val widgetPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = result.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (result.resultCode == RESULT_OK && id != AppWidgetManager.INVALID_APPWIDGET_ID) {
            finishWidgetSelection(id)
        } else if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
            widgetHost.deleteAppWidgetId(id)
        }
    }

    private val widgetConfiguration = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val id = pendingConfigurationWidgetId
        pendingConfigurationWidgetId = null
        if (id != null && it.resultCode == RESULT_OK) addWidgetPlacement(id, pendingWidgetPage)
        else if (id != null) widgetHost.deleteAppWidgetId(id)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetHost = HomeAppWidgetHost(this)
        lifecycleScope.launch {
            // Complete the Room/legacy recovery bridge before Compose reads workspace preferences.
            runCatching { RoomWorkspaceStore.migrateLegacyPreferences(applicationContext) }
            nativeWidgets.clear()
            nativeWidgets.addAll(loadNativeWidgetPlacements(this@MainActivity))
            setContent { HomePrototype(this@MainActivity) }
        }
    }

    override fun onStart() {
        super.onStart()
        if (::widgetHost.isInitialized) runCatching { widgetHost.startListening() }
    }

    override fun onStop() {
        if (::widgetHost.isInitialized) runCatching { widgetHost.stopListening() }
        super.onStop()
    }

    fun pickNativeWidget(page: Int) {
        pendingWidgetPage = page.coerceIn(0, 2)
        val id = widgetHost.allocateAppWidgetId()
        val pickIntent = android.content.Intent(AppWidgetManager.ACTION_APPWIDGET_PICK)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        widgetPicker.launch(pickIntent)
    }

    private fun finishWidgetSelection(id: Int) {
        val manager = AppWidgetManager.getInstance(this)
        // ACTION_APPWIDGET_PICK returns an already-bound ID. Verify it before keeping it.
        val info = manager.getAppWidgetInfo(id)
        if (info == null) {
            widgetHost.deleteAppWidgetId(id)
            return
        }
        val configure = info.configure
        if (configure != null) {
            pendingConfigurationWidgetId = id
            widgetConfiguration.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                .setComponent(configure)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        } else addWidgetPlacement(id, pendingWidgetPage)
    }

    private fun addWidgetPlacement(id: Int, page: Int) {
        nativeWidgets.removeAll { it.appWidgetId == id }
        nativeWidgets.add(NativeWidgetPlacement(id, page, 0.04f, 0.48f))
        saveNativeWidgetPlacements(this, nativeWidgets)
    }

    fun removeNativeWidget(id: Int) {
        nativeWidgets.removeAll { it.appWidgetId == id }
        saveNativeWidgetPlacements(this, nativeWidgets)
        widgetHost.deleteAppWidgetId(id)
    }

    fun persistNativeWidgets() = saveNativeWidgetPlacements(this, nativeWidgets)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomePrototype(activity: MainActivity) {
    val context = LocalContext.current
    val packageManager = context.packageManager
    val apps = remember { loadLaunchableApps(context) }
    val prefs = remember { context.getSharedPreferences("home_workspace", Context.MODE_PRIVATE) }
    var page by remember { mutableIntStateOf(prefs.getInt("active_page", 0).coerceIn(0, 2)) }
    var gridMode by remember { mutableStateOf(prefs.getBoolean("grid_mode", true)) }
    var wideMode by remember { mutableStateOf(prefs.getBoolean("wide_workspace", false)) }
    var editing by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var homeWidgetStudio by remember { mutableStateOf(false) }
    var editingWidgetId by remember { mutableStateOf<String?>(null) }
    var homeWidgets by remember { mutableStateOf(loadHomeWidgets(context)) }
    var placements by remember { mutableStateOf(loadPlacements(prefs, apps)) }
    var menuTarget by remember { mutableStateOf<AppMenuTarget?>(null) }

    fun persist() {
        prefs.edit().putInt("active_page", page).putBoolean("grid_mode", gridMode).putBoolean("wide_workspace", wideMode)
            .putString("placements", JSONArray().apply {
                placements.forEach { p -> put(JSONObject().put("pkg", p.packageName).put("page", p.page).put("x", p.x).put("y", p.y)) }
            }.toString()).apply()
        RoomWorkspaceStore.scheduleMirror(context)
    }

    menuTarget?.let { target ->
        val label = apps.firstOrNull { it.packageName == target.packageName }?.label ?: target.packageName
        AlertDialog(
            onDismissRequest = { menuTarget = null },
            title = { Text(label) },
            text = {
                Column {
                    TextButton(onClick = { openAppInfo(context, target.packageName); menuTarget = null }) { Text("App info") }
                    TextButton(onClick = { uninstallApp(context, target.packageName); menuTarget = null }) { Text("Uninstall") }
                    val placed = target.placed
                    if (placed != null) {
                        TextButton(onClick = {
                            placements = placements.filterNot { it.packageName == placed.packageName && it.page == placed.page }
                            persist()
                            menuTarget = null
                        }) { Text("Remove from screen") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuTarget = null }) { Text("CANCEL") } }
        )
    }

    val exportHomepack = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) runCatching {
            val widgetsJson = JSONArray().apply {
                homeWidgets.forEach { w -> put(JSONObject().put("id", w.id).put("name", w.name).put("type", w.type)
                    .put("bg", w.backgroundArgb).put("fg", w.foregroundArgb).put("24h", w.use24Hour).put("date", w.showDate)
                    .put("scale", w.fontScale.toDouble()).put("x", w.x.toDouble()).put("y", w.y.toDouble())
                    .put("w", w.widthDp).put("h", w.heightDp).put("page", w.page).put("components", componentsToJson(w.components))) }
            }
            val shortcutsJson = JSONArray().apply {
                placements.forEach { p -> put(JSONObject().put("pkg", p.packageName).put("page", p.page).put("x", p.x.toDouble()).put("y", p.y.toDouble())) }
            }
            val assets = Homepack.preparePortableWidgets(context, widgetsJson)
            context.contentResolver.openOutputStream(uri)?.use { Homepack.write(it, widgetsJson, shortcutsJson, assets, JSONObject().put("mode", if (wideMode) "WIDE" else if (!gridMode) "FREEFORM" else "PAGED").put("widthScreens", 3).put("heightScreens", 1).put("snapToScreens", true)) }
                ?: error("Cannot open destination")
        }.onFailure { android.widget.Toast.makeText(context, "Export failed: ${it.message}", android.widget.Toast.LENGTH_LONG).show() }
    }
    val importHomepack = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val workspace = context.contentResolver.openInputStream(uri)?.use { Homepack.read(it) } ?: error("Cannot open file")
            Homepack.restorePortableAssets(context, workspace)
            val canvasConfig = workspace.optJSONObject("canvas")
            if (canvasConfig != null) {
                val importedMode = canvasConfig.optString("mode", "PAGED")
                wideMode = importedMode == "WIDE"
                if (importedMode == "FREEFORM") gridMode = false
                prefs.edit().putBoolean("wide_workspace", wideMode).putBoolean("grid_mode", gridMode).apply()
            }
            val importedWidgets = workspace.getJSONArray("widgets")
            val restored = (0 until importedWidgets.length()).map { i ->
                val o = importedWidgets.getJSONObject(i)
                HomeWidgetDefinition(id = o.optString("id"), name = o.optString("name", "Clock"), type = o.optString("type", "clock"),
                    backgroundArgb = o.optLong("bg", 0xFF253247), foregroundArgb = o.optLong("fg", -1L),
                    use24Hour = o.optBoolean("24h", true), showDate = o.optBoolean("date", true),
                    fontScale = o.optDouble("scale", 1.0).toFloat().coerceIn(0.7f, 1.5f),
                    x = o.optDouble("x", 0.04).toFloat().coerceIn(0f, 0.9f), y = o.optDouble("y", 0.12).toFloat().coerceIn(0f, 0.9f),
                    widthDp = o.optInt("w", 220).coerceIn(140, 420), heightDp = o.optInt("h", 112).coerceIn(80, 260), page = o.optInt("page", 0).coerceIn(0, 2), components = componentsFromJson(o.optJSONArray("components")))
            }
            val ids = homeWidgets.map { it.id }.toMutableSet()
            val uniqueWidgets = restored.map { item ->
                if (item.id in ids) item.copy(id = java.util.UUID.randomUUID().toString()).also { ids.add(it.id) }
                else item.also { ids.add(it.id) }
            }
            homeWidgets = homeWidgets + uniqueWidgets
            saveHomeWidgets(context, homeWidgets)
            val importedShortcuts = workspace.optJSONArray("shortcuts") ?: JSONArray()
            val merged = placements.toMutableList()
            for (i in 0 until importedShortcuts.length()) {
                val o = importedShortcuts.getJSONObject(i)
                val pkg = o.optString("pkg")
                if (apps.any { it.packageName == pkg } && merged.none { it.packageName == pkg && it.page == o.optInt("page") }) {
                    merged.add(PlacedApp(pkg, o.optInt("page", 0).coerceIn(0, 2), o.optDouble("x", 0.1).toFloat().coerceIn(0f, 0.9f), o.optDouble("y", 0.1).toFloat().coerceIn(0f, 0.9f)))
                }
            }
            placements = merged
            persist()
            android.widget.Toast.makeText(context, "Homepack imported", android.widget.Toast.LENGTH_SHORT).show()
        }.onFailure { android.widget.Toast.makeText(context, "Import failed: ${it.message}", android.widget.Toast.LENGTH_LONG).show() }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF10131A), surface = Color(0xFF1B202B), primary = Color(0xFF8AB4F8),
        onSurface = Color.White
    )) {
        Box(Modifier.fillMaxSize().background(Color(0xFF10131A))) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("HOME", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (editing) TextButton(onClick = { gridMode = !gridMode; persist() }) { Text(if (gridMode) "GRID" else "FREE") }
                        TextButton(onClick = { wideMode = !wideMode; persist() }) { Text(if (wideMode) "WIDE" else "PAGED") }
                        TextButton(onClick = { editing = !editing }) { Text(if (editing) "DONE" else "EDIT") }
                    }
                }
                Spacer(Modifier.height(12.dp))
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().clipToBounds().pointerInput(editing) {
                    // Swipe between workspaces (disabled in edit mode, where drags move elements).
                    if (!editing) {
                        var totalDrag = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { totalDrag = 0f },
                            onDragCancel = { totalDrag = 0f },
                            onDragEnd = {
                                if (totalDrag < -100f && page < 2) { page += 1; persist() }
                                else if (totalDrag > 100f && page > 0) { page -= 1; persist() }
                                totalDrag = 0f
                            }
                        ) { _, dragAmount -> totalDrag += dragAmount }
                    }
                }) {
                    val canvasWidth = constraints.maxWidth.toFloat().coerceAtLeast(1f)
                    val canvasHeight = constraints.maxHeight.toFloat().coerceAtLeast(1f)
                    if (editing && gridMode) {
                        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                            repeat(8) { Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                repeat(5) { Box(Modifier.weight(1f).fillMaxHeight().padding(3.dp).background(Color(0x182F80ED), RoundedCornerShape(6.dp))) }
                            } }
                        }
                    }
                    Box(
                        Modifier.requiredWidth(maxWidth * if (wideMode) 3f else 1f)
                            .fillMaxHeight()
                            .offset { IntOffset(if (wideMode) -(page * canvasWidth).roundToInt() else 0, 0) }
                    ) {
                    val current = if (wideMode) placements else placements.filter { it.page == page }
                    current.forEach { placed ->
                        val app = apps.firstOrNull { it.packageName == placed.packageName } ?: return@forEach
                        var x by remember(placed.packageName, placed.page) { mutableFloatStateOf(placed.x) }
                        var y by remember(placed.packageName, placed.page) { mutableFloatStateOf(placed.y) }
                        Column(
                            modifier = Modifier.offset { IntOffset(((if (wideMode) placed.page * canvasWidth else 0f) + x * canvasWidth).roundToInt(), (y * canvasHeight).roundToInt()) }
                                .width(76.dp)
                                .pointerInput(editing, gridMode) {
                                    if (editing) detectDragGestures { change, drag ->
                                        change.consume()
                                        val nx = (x + drag.x / canvasWidth).coerceIn(0f, 0.82f)
                                        val ny = (y + drag.y / canvasHeight).coerceIn(0f, 0.88f)
                                        if (gridMode) {
                                            x = (nx * 5).roundToInt().coerceIn(0, 4) / 5f
                                            y = (ny * 8).roundToInt().coerceIn(0, 7) / 8f
                                        } else { x = nx; y = ny }
                                        placements = placements.map { if (it.packageName == placed.packageName && it.page == placed.page) it.copy(x = x, y = y) else it }
                                        persist()
                                    }
                                }
                                .combinedClickable(enabled = !editing, onLongClick = { menuTarget = AppMenuTarget(app.packageName, placed) }) { launchApp(context, app) }
                                .padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            AppIcon(app.icon, Modifier.size(42.dp))
                            Text(app.label, color = Color.White, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                    homeWidgets.filter { wideMode || it.page == page }.forEach { widget ->
                        key(widget.id) {
                            var wx by remember(widget.id) { mutableFloatStateOf(widget.x) }
                            var wy by remember(widget.id) { mutableFloatStateOf(widget.y) }
                            var ww by remember(widget.id) { mutableIntStateOf(widget.widthDp) }
                            var wh by remember(widget.id) { mutableIntStateOf(widget.heightDp) }
                            Column(Modifier.offset { IntOffset(((if (wideMode) widget.page * canvasWidth else 0f) + wx * canvasWidth).roundToInt(), (wy * canvasHeight).roundToInt()) }
                                .width(ww.dp).height(wh.dp).zIndex(1f)) {
                                if (editing) {
                                    Row(Modifier.fillMaxWidth().height(30.dp).background(Color(0xFF303949), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)),
                                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                                        Text("HOME", color = Color.White, fontSize = 9.sp, modifier = Modifier.pointerInput(widget.id, canvasWidth, canvasHeight) {
                                            detectDragGestures { change, drag ->
                                                change.consume()
                                                wx = (wx + drag.x / canvasWidth).coerceIn(0f, 0.88f)
                                                wy = (wy + drag.y / canvasHeight).coerceIn(0f, 0.88f)
                                                homeWidgets = homeWidgets.map { if (it.id == widget.id) it.copy(x = wx, y = wy) else it }
                                                saveHomeWidgets(context, homeWidgets)
                                            }
                                        })
                                        TextButton(onClick = { editingWidgetId = widget.id; homeWidgetStudio = true }, contentPadding = PaddingValues(0.dp)) { Text("EDIT", color = Color.White, fontSize = 9.sp) }
                                        TextButton(onClick = { ww = (ww - 20).coerceAtLeast(160); wh = (wh - 12).coerceAtLeast(88); homeWidgets = homeWidgets.map { if (it.id == widget.id) it.copy(widthDp = ww, heightDp = wh) else it }; saveHomeWidgets(context, homeWidgets) }, contentPadding = PaddingValues(0.dp)) { Text("−", color = Color.White) }
                                        TextButton(onClick = { ww = (ww + 20).coerceAtMost(420); wh = (wh + 12).coerceAtMost(260); homeWidgets = homeWidgets.map { if (it.id == widget.id) it.copy(widthDp = ww, heightDp = wh) else it }; saveHomeWidgets(context, homeWidgets) }, contentPadding = PaddingValues(0.dp)) { Text("+", color = Color.White) }
                                        TextButton(onClick = { homeWidgets = homeWidgets.filterNot { it.id == widget.id }; saveHomeWidgets(context, homeWidgets) }, contentPadding = PaddingValues(0.dp)) { Text("×", color = Color(0xFFFF8A80)) }
                                    }
                                }
                                HomeWidgetRenderer(widget, Modifier.fillMaxWidth().weight(1f), editing)
                            }
                        }
                    }
                    activity.nativeWidgets.filter { wideMode || it.page == page }.forEach { widget ->
                        key(widget.appWidgetId) {
                            var wx by remember(widget.appWidgetId) { mutableFloatStateOf(widget.x) }
                            var wy by remember(widget.appWidgetId) { mutableFloatStateOf(widget.y) }
                            var ww by remember(widget.appWidgetId) { mutableIntStateOf(widget.widthDp) }
                            var wh by remember(widget.appWidgetId) { mutableIntStateOf(widget.heightDp) }
                            val appWidgetView = remember(widget.appWidgetId) {
                                runCatching {
                                    val info = AppWidgetManager.getInstance(context).getAppWidgetInfo(widget.appWidgetId)
                                    if (info != null) activity.widgetHost.createView(context, widget.appWidgetId, info) else null
                                }.getOrNull()
                            }
                            if (appWidgetView != null) {
                                Column(
                                    Modifier.offset { IntOffset(((if (wideMode) widget.page * canvasWidth else 0f) + wx * canvasWidth).roundToInt(), (wy * canvasHeight).roundToInt()) }
                                        .width(ww.dp).height(wh.dp).zIndex(2f)
                                ) {
                                    if (editing) {
                                        Row(
                                            Modifier.fillMaxWidth().height(30.dp).background(Color(0xFF303949), RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceEvenly
                                        ) {
                                            Text("WIDGET", color = Color.White, fontSize = 10.sp, modifier = Modifier.pointerInput(widget.appWidgetId) {
                                                detectDragGestures { change, drag ->
                                                    change.consume()
                                                    wx = (wx + drag.x / canvasWidth).coerceIn(0f, 0.9f)
                                                    wy = (wy + drag.y / canvasHeight).coerceIn(0f, 0.9f)
                                                    val idx = activity.nativeWidgets.indexOfFirst { it.appWidgetId == widget.appWidgetId }
                                                    if (idx >= 0) activity.nativeWidgets[idx] = widget.copy(x = wx, y = wy, widthDp = ww, heightDp = wh)
                                                    activity.persistNativeWidgets()
                                                }
                                            })
                                            TextButton(onClick = { ww = (ww - 30).coerceAtLeast(160); updateWidget(activity, widget, wx, wy, ww, wh) }, contentPadding = PaddingValues(0.dp)) { Text("−", color = Color.White) }
                                            Text("${ww}×${wh}", color = Color.White, fontSize = 9.sp)
                                            TextButton(onClick = { ww = (ww + 30).coerceAtMost(600); wh = (wh + 20).coerceAtMost(600); updateWidget(activity, widget, wx, wy, ww, wh) }, contentPadding = PaddingValues(0.dp)) { Text("+", color = Color.White) }
                                            TextButton(onClick = { activity.removeNativeWidget(widget.appWidgetId) }, contentPadding = PaddingValues(0.dp)) { Text("×", color = Color(0xFFFF8A80)) }
                                        }
                                    }
                                    AndroidView(
                                        modifier = Modifier.fillMaxSize().background(Color(0xFF202633), RoundedCornerShape(10.dp)),
                                        factory = { appWidgetView },
                                    )
                                }
                            }
                        }
                    }
                    } // panoramic canvas content
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    repeat(3) { index -> TextButton(onClick = { page = index; persist() }) { Text(if (page == index) "●" else "○", color = Color.White) } }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { drawerOpen = true; query = "" }) { Text("▦  APPS") }
                    if (editing) {
                        TextButton(onClick = { activity.pickNativeWidget(page) }) { Text("▣ ANDROID WIDGET") }
                        TextButton(onClick = { editingWidgetId = null; homeWidgetStudio = true }) { Text("◷ HOME WIDGET") }
                    }
                }
                if (editing) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    TextButton(onClick = { exportHomepack.launch("HOME-workspace.homepack") }) { Text("EXPORT") }
                    TextButton(onClick = { importHomepack.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Text("IMPORT") }
                }
            }

            if (homeWidgetStudio) {
                val existing = homeWidgets.firstOrNull { it.id == editingWidgetId }
                HomeWidgetStudio(initial = existing ?: HomeWidgetDefinition(type = "custom", name = "My Widget"), onCancel = { homeWidgetStudio = false; editingWidgetId = null }, onSave = { definition ->
                    homeWidgets = if (existing != null) homeWidgets.map { if (it.id == existing.id) definition.copy(page = existing.page, x = existing.x, y = existing.y, widthDp = existing.widthDp, heightDp = existing.heightDp) else it }
                        else homeWidgets + definition.copy(page = page, x = 0.06f, y = 0.12f)
                    saveHomeWidgets(context, homeWidgets)
                    homeWidgetStudio = false
                    editingWidgetId = null
                })
            }

            if (drawerOpen) {
                Surface(Modifier.fillMaxSize(), color = Color(0xF510131A)) {
                    Column(Modifier.fillMaxSize().padding(18.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Applications", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { drawerOpen = false }) { Text("CLOSE") }
                        }
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search apps") })
                        Spacer(Modifier.height(12.dp))
                        val filtered = apps.filter { it.label.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true) }
                        LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 20.dp)) {
                            items(filtered, key = { it.packageName }) { app ->
                                Column(Modifier.fillMaxWidth().combinedClickable(onLongClick = { menuTarget = AppMenuTarget(app.packageName, null) }) {
                                    if (editing) {
                                        if (placements.none { it.packageName == app.packageName && it.page == page }) {
                                            placements = placements + PlacedApp(app.packageName, page, 0.08f, 0.08f); persist()
                                        }
                                        drawerOpen = false
                                    } else { launchApp(context, app); drawerOpen = false }
                                }.padding(vertical = 12.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    AppIcon(app.icon, Modifier.size(42.dp))
                                    Text(app.label, color = Color.White, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                        }
                        Text(if (editing) "Tap an app to add it to this page" else "Tap an app to launch", color = Color(0xFF9AA5B5), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

private fun updateWidget(activity: MainActivity, old: NativeWidgetPlacement, x: Float, y: Float, width: Int, height: Int) {
    val index = activity.nativeWidgets.indexOfFirst { it.appWidgetId == old.appWidgetId }
    if (index >= 0) activity.nativeWidgets[index] = old.copy(x = x, y = y, widthDp = width, heightDp = height)
    val options = Bundle().apply {
        putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, width)
        putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, width)
        putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, height)
        putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, height)
    }
    AppWidgetManager.getInstance(activity).updateAppWidgetOptions(old.appWidgetId, options)
    activity.persistNativeWidgets()
}

@Composable
private fun AppIcon(drawable: Drawable, modifier: Modifier = Modifier) {
    AndroidView(modifier = modifier, factory = { ImageView(it).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setImageDrawable(drawable) } }, update = { it.setImageDrawable(drawable) })
}

private fun loadLaunchableApps(context: Context): List<LaunchableApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .mapNotNull { info ->
            val activity = info.activityInfo ?: return@mapNotNull null
            LaunchableApp(info.loadLabel(pm).toString(), activity.packageName, activity.name, info.loadIcon(pm))
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

private fun launchApp(context: Context, app: LaunchableApp) {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(app.packageName, app.activityName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
}

private fun loadPlacements(prefs: android.content.SharedPreferences, apps: List<LaunchableApp>): List<PlacedApp> {
    val raw = prefs.getString("placements", null)
    if (raw.isNullOrBlank()) return apps.take(5).mapIndexed { index, app ->
        PlacedApp(app.packageName, 0, 0.06f + (index % 3) * 0.28f, 0.08f + (index / 3) * 0.16f)
    }
    return runCatching {
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val o = array.getJSONObject(i)
            PlacedApp(o.getString("pkg"), o.optInt("page"), o.optDouble("x").toFloat(), o.optDouble("y").toFloat())
        }.filter { p -> apps.any { it.packageName == p.packageName } }
    }.getOrDefault(emptyList())
}

private data class AppMenuTarget(val packageName: String, val placed: PlacedApp?)

private fun openAppInfo(context: Context, packageName: String) {
    val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
}

/** Asks Android to uninstall the package; the system shows its own confirmation dialog. */
private fun uninstallApp(context: Context, packageName: String) {
    val intent = Intent(Intent.ACTION_DELETE, android.net.Uri.parse("package:$packageName"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
}
