# HOME 0.13.1

- Long-press menu on app icons (home screen and app drawer): App info (system settings page of the app), Uninstall (system confirmation dialog), and Remove from screen (home-screen icons only). Added the REQUEST_DELETE_PACKAGES permission required for uninstall requests.
- Graphics policy, stage 1: Homepack assets must be real PNG, JPEG or WebP images (detected from file bytes, max 4096 px per side). Other formats (SVG, GIF, Lottie, etc.) are rejected on import and skipped on export. Each asset's SHA-256 is verified against its file name on import.
- LayoutResolver: element min/max sizes are now always interpreted in dp, regardless of the coordinate unit.

## Compatibility
- Older Homepacks that contain assets in formats other than PNG/JPEG/WebP are now rejected on import.
- App shortcuts (quick actions declared by apps) are not included yet.

## Verification limits
Source-level changes only. Gradle/APK build and on-device behavior (long-press menu, uninstall flow, asset validation) have not been run.
