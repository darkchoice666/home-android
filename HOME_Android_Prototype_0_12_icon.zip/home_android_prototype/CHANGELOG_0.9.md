# HOME 0.9.0

- Added undo/redo history for component-tree edits (bounded to 40 snapshots).
- Added multi-selection in the Layers panel and bulk deletion.
- Fixed layer reordering so nested components can be moved among their siblings.
- Added center alignment guides to the editor canvas while grid snapping is enabled.
- Preserved the existing HomeComponent/Homepack JSON schema and legacy workspace storage.

## Known limitations

- Multi-selection is currently managed from the Layers panel; canvas gestures still select one component at a time.
- Undo/redo tracks component-tree edits, not every widget-level setting or Android system widget operation.
- Persistence remains SharedPreferences JSON; Room migration is intentionally deferred until a stable repository/data migration layer is introduced.
- APK compilation and device testing have not been performed in this environment.
