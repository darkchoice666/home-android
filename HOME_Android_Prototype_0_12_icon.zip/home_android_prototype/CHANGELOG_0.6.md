# HOME 0.6 — Visual Component Builder

## Added
- Declarative `HomeComponent` model with stable node IDs and bounded properties.
- Custom HOME widget type and renderer.
- Visual Builder mode alongside the existing clock editor.
- Text, image, shape, container-block, and spacer components.
- Live preview, layer selection, reordering, removal, text editing, color and size controls.
- Android document picker for images with persisted URI read permission request.
- Homepack v2 stores component arrays and validates supported node types and limits.
- Homepack v1 remains accepted for clock-only workspaces.

## Limitations
- Components currently render in a vertical stack; nested Row/Column trees and constraint-based responsive layouts are not implemented yet.
- Image bytes are not embedded in Homepack. The imported widget may show an empty image if the original URI is unavailable on the destination device.
- No APK build or device test is claimed.


## 0.7.0 — Freeform nested component canvas

- Extended HomeComponent with nested children, Row/Column/Box layout mode, normalized x/y/width/height bounds, and alpha.
- Added recursive JSON serialization/deserialization and bounded nested-tree validation.
- Added freeform root canvas rendering and drag-to-move in Studio preview, plus property sliders for bounds and opacity.
- Added nested child insertion and recursive selection/update/removal.
- Homepack schema v3 embeds image assets by SHA-256 name, restores them into app-private storage, and enforces per-file/aggregate limits.
- Kept v1/v2 package read compatibility.
- APK build and device execution are not verified in this environment.
