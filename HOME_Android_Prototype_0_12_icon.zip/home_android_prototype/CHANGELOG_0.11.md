# HOME 0.11.0 — normalized Room workspace model

- Expanded Room schema to version 2 with an explicit 1→2 migration.
- Added typed entities for workspace metadata, pages, app shortcuts, HOME Widgets, and Android AppWidgetHost placements.
- Added DAOs and `WorkspaceRepository` for typed snapshot reads.
- Legacy SharedPreferences JSON is parsed into normalized tables and committed as one Room transaction.
- Existing SharedPreferences remain the UI compatibility source during this iteration; Room is a structured mirror, not yet the canonical read/write path.
- Android `appWidgetId` remains device-local. It is not portable through Homepack.
- Homepack export/import format is unchanged.

## Verification limits

Source-level structural checks and archive integrity checks only. Gradle/APK build, Room migration execution on Android, and device tests were not run in this environment.
