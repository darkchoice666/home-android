# HOME 0.12.0 — startup recovery bridge

- Startup now completes the Room/legacy storage bridge before Compose reads workspace preferences.
- If the legacy `home_workspace` SharedPreferences file is unexpectedly empty but Room contains mirrored records, supported primitive values are restored before the launcher UI is created.
- If legacy preferences exist, they remain the compatibility authority and are imported without overwriting existing Room records.
- Mirroring is serialized with a coroutine Mutex; preference records and the normalized Room snapshot are updated through the storage bridge.
- Native Android widget placements are loaded after the recovery step, reducing the chance of initializing the UI from an empty legacy store.
- Kustom/third-party editor integration remains explicitly out of the core and is not included in this release.

## Verification limits

ZIP integrity, manifest XML, source structure and targeted recovery-path checks only. Gradle/APK build, Room migration execution on Android, crash-recovery behavior on a physical device, and OEM widget-host behavior have not been tested in this environment. Room remains a mirrored/recovery store; normal UI mutations still originate in the legacy SharedPreferences path.
