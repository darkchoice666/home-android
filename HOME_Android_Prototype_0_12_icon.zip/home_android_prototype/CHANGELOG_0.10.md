# HOME 0.10.0

## Added
- Room 2.6.1 database and DAO for durable workspace key/value records.
- Idempotent migration of existing `home_workspace` SharedPreferences values into Room.
- Transactional Room mirroring after shortcut placement, HOME Widget, and native widget saves.
- Typed legacy values (`string`, `boolean`, `int`, `long`, `float`) retain their type metadata.

## Compatibility and limitations
- SharedPreferences remains the active read source in 0.10. Room is a mirrored persistence layer; the canonical read-path migration is deliberately deferred until database-backed repositories and schema-specific entities are introduced.
- Existing workspace JSON and Homepack formats are unchanged. Android `appWidgetId` remains device-local.
- Migration is non-destructive: old preferences are never deleted. Existing Room keys are not overwritten during initial import.

## Validation
- ZIP integrity and source-level structural checks are run when packaging.
- Gradle build, Room annotation processing, APK installation, and device migration behavior are not verified in this environment.
