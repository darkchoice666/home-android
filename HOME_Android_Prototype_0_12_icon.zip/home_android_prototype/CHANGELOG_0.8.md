# HOME 0.8.0

## Studio canvas improvements
- Added selectable component outlines on the visual canvas.
- Added a bottom-right resize handle for the selected top-level component.
- Added optional alignment grid (20 columns × 10 rows) and snapping for move/resize gestures.
- Added direct canvas selection and selection-aware z-order highlighting.
- Kept the existing recursive component model and Homepack serialization unchanged; no schema migration is required.

## Scope / limitations
- The canvas currently manipulates top-level component bounds. Nested children are still edited through the component tree and property controls.
- The resize handle is a basic single-corner handle; edge-specific handles, multi-selection, undo/redo, and smart guides are not included yet.
- This source archive has not been compiled or tested on a physical Android device in this environment.
