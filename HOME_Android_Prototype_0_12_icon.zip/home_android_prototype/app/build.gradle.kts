plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.home.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.home.launcher"
        minSdk = 29
        targetSdk = 35
        versionCode = 12
        versionName = "0.12.0"
    }

    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}

 kapt { correctErrorTypes = true }


## 0.12.0 — startup recovery bridge

- Startup now runs the Room/legacy bridge before the Compose workspace reads SharedPreferences.
- If legacy preferences are empty while Room contains a prior mirror, supported primitive preference values are restored from Room.
- Existing legacy preferences remain authoritative when present; this is a recovery bridge, not yet a full Room-first repository migration.
- Mirroring operations are serialized to reduce overlapping background writes.
- Kustom and other external editors remain optional future integrations, outside the launcher core.

**Build status:** static source and archive checks only; APK and on-device tests have not been run.
