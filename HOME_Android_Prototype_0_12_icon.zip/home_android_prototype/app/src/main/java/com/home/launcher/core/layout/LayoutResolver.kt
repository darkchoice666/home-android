package com.home.launcher.core.layout

import com.home.launcher.core.model.*
import kotlin.math.max

data class Viewport(val widthPx: Float, val heightPx: Float, val density: Float)
data class ResolvedRect(val left: Float, val top: Float, val width: Float, val height: Float)

/** Resolves the shared GRID/FREE document geometry into physical pixels. */
object LayoutResolver {
    fun resolve(element: Element, page: Page, viewport: Viewport): ResolvedRect {
        val g = element.geometry
        val safeWidth = max(1f, viewport.widthPx)
        val safeHeight = max(1f, viewport.heightPx)
        val cellW = safeWidth / page.grid.columns
        val cellH = safeHeight / page.grid.rows

        val raw = when (element.positionMode) {
            PositionMode.GRID -> ResolvedRect(
                left = g.x * cellW,
                top = g.y * cellH,
                width = g.width * cellW,
                height = g.height * cellH
            )
            PositionMode.FREE -> when (g.unit) {
                CoordinateUnit.RELATIVE -> ResolvedRect(g.x * safeWidth, g.y * safeHeight, g.width * safeWidth, g.height * safeHeight)
                CoordinateUnit.DP -> ResolvedRect(g.x * viewport.density, g.y * viewport.density, g.width * viewport.density, g.height * viewport.density)
                CoordinateUnit.GRID -> ResolvedRect(g.x * cellW, g.y * cellH, g.width * cellW, g.height * cellH)
            }
        }
        val minW = g.minWidth?.let { if (g.unit == CoordinateUnit.DP) it * viewport.density else it } ?: 0f
        val minH = g.minHeight?.let { if (g.unit == CoordinateUnit.DP) it * viewport.density else it } ?: 0f
        val maxW = g.maxWidth?.let { if (g.unit == CoordinateUnit.DP) it * viewport.density else it } ?: Float.MAX_VALUE
        val maxH = g.maxHeight?.let { if (g.unit == CoordinateUnit.DP) it * viewport.density else it } ?: Float.MAX_VALUE
        return raw.copy(width = raw.width.coerceIn(minW, maxW), height = raw.height.coerceIn(minH, maxH))
    }
}
