package com.home.launcher.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Transitional key/value record. Values are serialized as strings to preserve legacy formats. */
@Entity(tableName = "workspace_records")
data class WorkspaceRecord(
    @PrimaryKey val recordKey: String,
    val value: String,
    val valueType: String,
    val updatedAt: Long
)

@Dao
interface WorkspaceRecordDao {
    @Query("SELECT * FROM workspace_records WHERE recordKey = :key LIMIT 1")
    suspend fun get(key: String): WorkspaceRecord?

    @Query("SELECT * FROM workspace_records ORDER BY recordKey")
    suspend fun getAll(): List<WorkspaceRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(records: List<WorkspaceRecord>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(records: List<WorkspaceRecord>)
}

@Database(entities = [WorkspaceRecord::class, WorkspaceMetaEntity::class, WorkspacePageEntity::class, ShortcutEntity::class, HomeWidgetEntity::class, NativeWidgetEntity::class], version = 2, exportSchema = false)
abstract class HomeDatabase : RoomDatabase() {
    abstract fun workspaceDao(): WorkspaceRecordDao
    abstract fun workspaceDaoV2(): WorkspaceDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS workspace_meta (id TEXT NOT NULL PRIMARY KEY, activePage INTEGER NOT NULL, gridMode INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS workspace_pages (pageIndex INTEGER NOT NULL PRIMARY KEY, title TEXT NOT NULL, orderIndex INTEGER NOT NULL, columns INTEGER NOT NULL, rows INTEGER NOT NULL, horizontalGapDp REAL NOT NULL, verticalGapDp REAL NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS shortcuts (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, packageName TEXT NOT NULL, pageIndex INTEGER NOT NULL, x REAL NOT NULL, y REAL NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_shortcuts_packageName ON shortcuts(packageName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_shortcuts_pageIndex ON shortcuts(pageIndex)")
                db.execSQL("CREATE TABLE IF NOT EXISTS home_widgets (widgetId TEXT NOT NULL PRIMARY KEY, pageIndex INTEGER NOT NULL, payloadJson TEXT NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_home_widgets_pageIndex ON home_widgets(pageIndex)")
                db.execSQL("CREATE TABLE IF NOT EXISTS native_widgets (appWidgetId INTEGER NOT NULL PRIMARY KEY, pageIndex INTEGER NOT NULL, x REAL NOT NULL, y REAL NOT NULL, widthDp INTEGER NOT NULL, heightDp INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_native_widgets_pageIndex ON native_widgets(pageIndex)")
            }
        }

        @Volatile private var INSTANCE: HomeDatabase? = null
        fun get(context: Context): HomeDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                HomeDatabase::class.java,
                "home_workspace.db"
            ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}

/** Room mirror for the existing SharedPreferences workspace. Does not delete or rewrite legacy data. */
object RoomWorkspaceStore {
    private const val PREFS = "home_workspace"
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mirrorMutex = Mutex()

    /**
     * One-time-safe startup bridge. Existing SharedPreferences win when present; if they are
     * unexpectedly empty, the last Room mirror is restored before the UI reads preferences.
     */
    suspend fun migrateLegacyPreferences(context: Context) = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val db = HomeDatabase.get(appContext)
        val dao = db.workspaceDao()
        val existingRoomRecords = dao.getAll()

        if (prefs.all.isEmpty() && existingRoomRecords.isNotEmpty()) {
            restorePreferences(prefs, existingRoomRecords)
        } else {
            val records = prefs.all.mapNotNull { (key, raw) -> raw?.toRecord(key) }
            db.withTransaction { dao.insertIfAbsent(records) }
        }
        WorkspaceRepository.syncFromLegacy(appContext)
    }

    private fun restorePreferences(
        prefs: android.content.SharedPreferences,
        records: List<WorkspaceRecord>
    ) {
        val editor = prefs.edit()
        records.forEach { record ->
            when (record.valueType) {
                "string" -> editor.putString(record.recordKey, record.value)
                "boolean" -> editor.putBoolean(record.recordKey, record.value.toBooleanStrictOrNull() ?: false)
                "int" -> record.value.toIntOrNull()?.let { editor.putInt(record.recordKey, it) }
                "long" -> record.value.toLongOrNull()?.let { editor.putLong(record.recordKey, it) }
                "float" -> record.value.toFloatOrNull()?.let { editor.putFloat(record.recordKey, it) }
            }
        }
        editor.commit()
    }

    suspend fun mirrorLegacyPreferences(context: Context) = withContext(Dispatchers.IO) {
        mirrorMutex.withLock {
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val records = prefs.all.mapNotNull { (key, raw) -> raw?.toRecord(key) }
            val db = HomeDatabase.get(context)
            db.withTransaction { db.workspaceDao().upsertAll(records) }
            WorkspaceRepository.syncFromLegacy(context.applicationContext)
        }
    }

    suspend fun readAll(context: Context): List<WorkspaceRecord> =
        HomeDatabase.get(context).workspaceDao().getAll()

    fun scheduleMirror(context: Context) {
        ioScope.launch { runCatching { mirrorLegacyPreferences(context) } }
    }

    private fun Any.toRecord(key: String): WorkspaceRecord? {
        val type = when (this) {
            is String -> "string"
            is Boolean -> "boolean"
            is Int -> "int"
            is Long -> "long"
            is Float -> "float"
            else -> return null
        }
        return WorkspaceRecord(key, toString(), type, System.currentTimeMillis())
    }

}
