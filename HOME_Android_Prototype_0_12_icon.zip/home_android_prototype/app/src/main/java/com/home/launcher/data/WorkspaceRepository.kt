package com.home.launcher.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "workspace_meta")
data class WorkspaceMetaEntity(
    @PrimaryKey val id: String = "default",
    val activePage: Int,
    val gridMode: Boolean,
    val updatedAt: Long
)

@Entity(tableName = "workspace_pages")
data class WorkspacePageEntity(
    @PrimaryKey val pageIndex: Int,
    val title: String,
    val orderIndex: Int,
    val columns: Int,
    val rows: Int,
    val horizontalGapDp: Float,
    val verticalGapDp: Float
)

@Entity(tableName = "shortcuts", indices = [Index("packageName"), Index("pageIndex")])
data class ShortcutEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val pageIndex: Int,
    val x: Float,
    val y: Float
)

@Entity(tableName = "home_widgets", indices = [Index("pageIndex")])
data class HomeWidgetEntity(
    @PrimaryKey val widgetId: String,
    val pageIndex: Int,
    val payloadJson: String,
    val updatedAt: Long
)

@Entity(tableName = "native_widgets", indices = [Index("pageIndex")])
data class NativeWidgetEntity(
    @PrimaryKey val appWidgetId: Int,
    val pageIndex: Int,
    val x: Float,
    val y: Float,
    val widthDp: Int,
    val heightDp: Int,
    val updatedAt: Long
)

@Dao
interface WorkspaceDao {
    @Query("SELECT * FROM workspace_meta WHERE id = 'default' LIMIT 1")
    suspend fun getMeta(): WorkspaceMetaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putMeta(value: WorkspaceMetaEntity)

    @Query("SELECT * FROM workspace_pages ORDER BY orderIndex")
    suspend fun getPages(): List<WorkspacePageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putPages(values: List<WorkspacePageEntity>)

    @Query("DELETE FROM workspace_pages")
    suspend fun clearPages()

    @Query("SELECT * FROM shortcuts ORDER BY pageIndex, id")
    suspend fun getShortcuts(): List<ShortcutEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putShortcuts(values: List<ShortcutEntity>)

    @Query("DELETE FROM shortcuts")
    suspend fun clearShortcuts()

    @Query("SELECT * FROM home_widgets ORDER BY pageIndex")
    suspend fun getHomeWidgets(): List<HomeWidgetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putHomeWidgets(values: List<HomeWidgetEntity>)

    @Query("DELETE FROM home_widgets")
    suspend fun clearHomeWidgets()

    @Query("SELECT * FROM native_widgets ORDER BY pageIndex")
    suspend fun getNativeWidgets(): List<NativeWidgetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putNativeWidgets(values: List<NativeWidgetEntity>)

    @Query("DELETE FROM native_widgets")
    suspend fun clearNativeWidgets()
}

/**
 * Typed normalized Room representation. SharedPreferences remains the active UI store in 0.11;
 * each successful legacy save is mirrored atomically into these tables.
 */
object WorkspaceRepository {
    private const val PREFS = "home_workspace"

    suspend fun syncFromLegacy(context: Context) {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val db = HomeDatabase.get(appContext)
        val dao = db.workspaceDaoV2()
        val now = System.currentTimeMillis()

        val shortcuts = parseArray(prefs.getString("placements", null)).mapNotNull { item ->
            val packageName = item.optString("pkg").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            ShortcutEntity(
                packageName = packageName,
                pageIndex = item.optInt("page", 0).coerceIn(0, 2),
                x = item.optDouble("x", 0.08).toFloat().coerceIn(0f, 1f),
                y = item.optDouble("y", 0.08).toFloat().coerceIn(0f, 1f)
            )
        }

        val widgets = parseArray(prefs.getString("home_widgets", null)).mapNotNull { item ->
            val id = item.optString("id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            HomeWidgetEntity(
                widgetId = id,
                pageIndex = item.optInt("page", 0).coerceIn(0, 2),
                payloadJson = item.toString(),
                updatedAt = now
            )
        }

        val nativeWidgets = parseArray(prefs.getString("native_widgets", null)).mapNotNull { item ->
            val id = item.optInt("id", -1)
            if (id < 0) return@mapNotNull null
            NativeWidgetEntity(
                appWidgetId = id,
                pageIndex = item.optInt("page", 0).coerceIn(0, 2),
                x = item.optDouble("x", 0.04).toFloat().coerceIn(0f, 1f),
                y = item.optDouble("y", 0.5).toFloat().coerceIn(0f, 1f),
                widthDp = item.optInt("w", 300).coerceIn(160, 600),
                heightDp = item.optInt("h", 180).coerceIn(100, 600),
                updatedAt = now
            )
        }

        val pages = (0..2).map { index ->
            WorkspacePageEntity(
                pageIndex = index,
                title = "Page ${index + 1}",
                orderIndex = index,
                columns = 5,
                rows = 8,
                horizontalGapDp = 8f,
                verticalGapDp = 8f
            )
        }

        db.withTransaction {
            dao.putMeta(
                WorkspaceMetaEntity(
                    activePage = prefs.getInt("active_page", 0).coerceIn(0, 2),
                    gridMode = prefs.getBoolean("grid_mode", true),
                    updatedAt = now
                )
            )
            dao.clearPages()
            dao.putPages(pages)
            dao.clearShortcuts()
            dao.putShortcuts(shortcuts)
            dao.clearHomeWidgets()
            dao.putHomeWidgets(widgets)
            dao.clearNativeWidgets()
            dao.putNativeWidgets(nativeWidgets)
        }
    }

    suspend fun loadSnapshot(context: Context): WorkspaceSnapshot {
        val dao = HomeDatabase.get(context.applicationContext).workspaceDaoV2()
        return WorkspaceSnapshot(
            meta = dao.getMeta(),
            pages = dao.getPages(),
            shortcuts = dao.getShortcuts(),
            homeWidgets = dao.getHomeWidgets(),
            nativeWidgets = dao.getNativeWidgets()
        )
    }

    private fun parseArray(raw: String?): List<JSONObject> = runCatching {
        if (raw.isNullOrBlank()) emptyList()
        else JSONArray(raw).let { array ->
            (0 until array.length()).mapNotNull { array.optJSONObject(it) }
        }
    }.getOrDefault(emptyList())
}

data class WorkspaceSnapshot(
    val meta: WorkspaceMetaEntity?,
    val pages: List<WorkspacePageEntity>,
    val shortcuts: List<ShortcutEntity>,
    val homeWidgets: List<HomeWidgetEntity>,
    val nativeWidgets: List<NativeWidgetEntity>
)
