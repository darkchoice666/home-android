package com.home.launcher.core.model

import java.util.UUID

enum class ElementType { APP_ICON, FOLDER, NATIVE_WIDGET, HOME_WIDGET, IMAGE, TEXT, SHAPE, GROUP }
enum class PositionMode { GRID, FREE }
enum class CoordinateUnit { RELATIVE, DP, GRID }
enum class Anchor { TOP_START, TOP_CENTER, TOP_END, CENTER_START, CENTER, CENTER_END, BOTTOM_START, BOTTOM_CENTER, BOTTOM_END }

data class Geometry(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val unit: CoordinateUnit = CoordinateUnit.RELATIVE,
    val anchor: Anchor = Anchor.TOP_START,
    val minWidth: Float? = null,
    val maxWidth: Float? = null,
    val minHeight: Float? = null,
    val maxHeight: Float? = null
)

data class Element(
    val id: String = UUID.randomUUID().toString(),
    val pageId: String,
    val type: ElementType,
    val positionMode: PositionMode,
    val geometry: Geometry,
    val rotation: Float = 0f,
    val scale: Float = 1f,
    val zIndex: Int = 0,
    val opacity: Float = 1f,
    val locked: Boolean = false,
    val groupId: String? = null,
    val label: String = ""
)

data class GridConfig(val columns: Int = 5, val rows: Int = 8, val horizontalGapDp: Float = 8f, val verticalGapDp: Float = 8f)

data class Page(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val orderIndex: Int,
    val grid: GridConfig = GridConfig(),
    val elements: List<Element> = emptyList()
)

data class Workspace(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "My Home",
    val activePageIndex: Int = 0,
    val pages: List<Page>
)
