package com.home.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.Context
import com.home.launcher.data.RoomWorkspaceStore

/** Owns widget IDs and the real Android AppWidgetHost connection. */
class HomeAppWidgetHost(context: Context) : AppWidgetHost(context, HOST_ID) {
    companion object {
        const val HOST_ID = 0x484F4D45 // "HOME"
    }
}

data class NativeWidgetPlacement(
    val appWidgetId: Int,
    val page: Int,
    val x: Float,
    val y: Float,
    val widthDp: Int = 300,
    val heightDp: Int = 180
)

fun loadNativeWidgetPlacements(context: Context): List<NativeWidgetPlacement> {
    val raw = context.getSharedPreferences("home_workspace", Context.MODE_PRIVATE)
        .getString("native_widgets", null) ?: return emptyList()
    return runCatching {
        val array = org.json.JSONArray(raw)
        (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            NativeWidgetPlacement(
                appWidgetId = item.getInt("id"),
                page = item.optInt("page", 0).coerceIn(0, 2),
                x = item.optDouble("x", 0.04).toFloat().coerceIn(0f, 0.9f),
                y = item.optDouble("y", 0.5).toFloat().coerceIn(0f, 0.9f),
                widthDp = item.optInt("w", 300).coerceIn(160, 600),
                heightDp = item.optInt("h", 180).coerceIn(100, 600)
            )
        }
    }.getOrDefault(emptyList())
}

fun saveNativeWidgetPlacements(context: Context, placements: List<NativeWidgetPlacement>) {
    val array = org.json.JSONArray()
    placements.forEach { widget ->
        array.put(org.json.JSONObject()
            .put("id", widget.appWidgetId)
            .put("page", widget.page)
            .put("x", widget.x.toDouble())
            .put("y", widget.y.toDouble())
            .put("w", widget.widthDp)
            .put("h", widget.heightDp))
    }
    context.getSharedPreferences("home_workspace", Context.MODE_PRIVATE)
        .edit().putString("native_widgets", array.toString()).apply()
    RoomWorkspaceStore.scheduleMirror(context)
}
